#!/usr/bin/env python3
"""Windows-only paired-case benchmark. No kernel edits, tuning, or adoption."""
import argparse,array,csv,ctypes,hashlib,json,math,os,platform,queue,random,shutil,statistics,subprocess,sys,threading,time,zipfile
from pathlib import Path
METRICS=['rtf_p50','ttfa_p50_ms','frame_p95_ms','frame_p99_ms']
def digest(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda:f.read(1048576),b''):h.update(chunk)
    return h.hexdigest()
def percentile(values,q):
    if not values:raise ValueError('empty observations')
    v=sorted(values)
    if not all(math.isfinite(x) for x in v):raise ValueError('nonfinite observations')
    pos=(len(v)-1)*q;i=int(pos);j=min(i+1,len(v)-1)
    return v[i]+(v[j]-v[i])*(pos-i)
def batch_summary(rows):
    if not rows:raise ValueError('empty batch')
    frames=[x for r in rows for x in r['frame_ms']]
    for r in rows:
        if not r['samples'] or r['frames']!=len(r['frame_ms']) or not all(math.isfinite(r[k]) and r[k]>0 for k in ['rtf','ttfa_ms','total_ms']):raise ValueError('invalid request metrics')
    return {'rtf_p50':statistics.median(r['rtf'] for r in rows),'ttfa_p50_ms':statistics.median(r['ttfa_ms'] for r in rows),
        'frame_p95_ms':percentile(frames,.95),'frame_p99_ms':percentile(frames,.99)}
def spread(a,b):
    return abs(a-b)/min(a,b) if min(a,b)>0 else 1.0

def design(cases,cycles,seed):
    """Each case gets both ABBA and BAAB across an even number of cycles."""
    result=[]
    for cycle in range(cycles):
        order=list(enumerate(cases));random.Random(seed+cycle).shuffle(order)
        for case_index,case in order:
            pattern='ABBA' if (cycle+case_index)%2==0 else 'BAAB'
            kinds=['candidate','control'] if (cycle+case_index)%2==0 else ['control','candidate']
            for kind in kinds:result.append({'cycle':cycle,'case':case,'kind':kind,'pattern':pattern})
    return result

def block_analysis(batches,kind,drift_limit,control_limit,busy_limit,pre,post):
    groups={letter:[b['summary'] for b in batches if b['letter']==letter] for letter in 'AB'}
    if any(len(v)!=2 for v in groups.values()):raise ValueError('incomplete ABBA/BAAB block')
    ratios={m:statistics.median(x[m] for x in groups['B'])/statistics.median(x[m] for x in groups['A']) for m in METRICS}
    flags=[]
    for letter in 'AB':
        if spread(groups[letter][0]['rtf_p50'],groups[letter][1]['rtf_p50'])>drift_limit:flags.append(letter+'_rtf_repeat_drift')
    if kind=='control' and abs(ratios['rtf_p50']-1)>control_limit:flags.append('baseline_control_contrast')
    for when,snapshot in [('before',pre),('after',post)]:
        busy=snapshot.get('idle_window_host_busy_pct')
        if busy is None:flags.append(when+'_load_unavailable')
        elif busy>busy_limit:flags.append(when+'_background_busy')
        ac=snapshot.get('power',{}).get('ac_line_status')
        if ac==0:flags.append(when+'_on_battery')
        elif ac!=1:flags.append(when+'_power_unknown')
        if snapshot.get('power',{}).get('battery_saver')==1:flags.append(when+'_battery_saver')
    if pre.get('power',{}).get('ac_line_status')!=post.get('power',{}).get('ac_line_status'):flags.append('ac_status_changed')
    if not all(b['numerical']['pass'] for b in batches):flags.append('numerical_failure')
    return {'ratios':ratios,'flags':flags,'unstable':bool(flags),'discarded':False}

class WindowsTelemetry:
    class FT(ctypes.Structure):_fields_=[('lo',ctypes.c_uint32),('hi',ctypes.c_uint32)]
    class Power(ctypes.Structure):
        _fields_=[('ac',ctypes.c_ubyte),('flag',ctypes.c_ubyte),('percent',ctypes.c_ubyte),('reserved',ctypes.c_ubyte),('life',ctypes.c_uint32),('full',ctypes.c_uint32)]
    def __init__(self):
        self.k=ctypes.WinDLL('kernel32',use_last_error=True)
        self.k.GetSystemTimes.argtypes=[ctypes.POINTER(self.FT)]*3;self.k.GetSystemTimes.restype=ctypes.c_int
        self.k.GetSystemPowerStatus.argtypes=[ctypes.POINTER(self.Power)];self.k.GetSystemPowerStatus.restype=ctypes.c_int
        self.k.OpenProcess.argtypes=[ctypes.c_uint32,ctypes.c_int,ctypes.c_uint32];self.k.OpenProcess.restype=ctypes.c_void_p
        self.k.GetProcessTimes.argtypes=[ctypes.c_void_p]+[ctypes.POINTER(self.FT)]*4;self.k.GetProcessTimes.restype=ctypes.c_int
        self.k.CloseHandle.argtypes=[ctypes.c_void_p];self.k.CloseHandle.restype=ctypes.c_int
    @staticmethod
    def value(x):return ((x.hi<<32)|x.lo)/10000000.0
    def system(self):
        idle,kernel,user=self.FT(),self.FT(),self.FT()
        if not self.k.GetSystemTimes(ctypes.byref(idle),ctypes.byref(kernel),ctypes.byref(user)):return None
        return {'idle':self.value(idle),'total':self.value(kernel)+self.value(user)}
    def process(self,pid):
        handle=self.k.OpenProcess(0x1000,0,pid)
        if not handle:return None
        try:
            c,e,k,u=self.FT(),self.FT(),self.FT(),self.FT()
            if not self.k.GetProcessTimes(handle,*[ctypes.byref(x) for x in [c,e,k,u]]):return None
            return self.value(k)+self.value(u)
        finally:self.k.CloseHandle(handle)
    def power(self):
        p=self.Power()
        if not self.k.GetSystemPowerStatus(ctypes.byref(p)):return {'error':'GetSystemPowerStatus unavailable'}
        return {'ac_line_status':int(p.ac),'battery_flag':int(p.flag),'battery_percent':None if p.percent==255 else int(p.percent),'battery_seconds':None if p.life==0xffffffff else int(p.life),'battery_saver':int(p.reserved)}
    def idle_observation(self,seconds=.3):
        a=self.system();time.sleep(seconds);b=self.system();busy=None
        if a and b and b['total']>a['total']:
            busy=100*max(0,min(1,1-(b['idle']-a['idle'])/(b['total']-a['total'])))
        return {'timestamp':time.time(),'idle_window_seconds':seconds,'idle_window_host_busy_pct':busy,'power':self.power(),
            'interpretation':'host busy while benchmark workers idle; proxy for background load, not process attribution'}

class Worker:
    def __init__(self,name,exe,model,pcm,out,env,timeout):
        self.name=name;self.pcm=pcm;self.timeout=timeout;self.q=queue.Queue();self.err=(out/(name+'-stderr.log')).open('w',encoding='utf-8')
        self.p=subprocess.Popen([str(exe),str(model),str(pcm)],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=self.err,text=True,encoding='utf-8',bufsize=1,env=env)
        def reader():
            try:
                for line in self.p.stdout:self.q.put(line)
            finally:self.q.put(None)
        threading.Thread(target=reader,daemon=True).start()
        try:
            ready=self.read()
            if ready.get('ready') is not True or ready.get('backend')!='avx2_fma':raise RuntimeError('unexpected worker backend '+name)
        except BaseException:self.close();raise
    def read(self):
        try:line=self.q.get(timeout=self.timeout)
        except queue.Empty:raise RuntimeError('worker timeout: '+self.name)
        if line is None:raise RuntimeError('worker exited: '+self.name+'; inspect stderr log')
        value=json.loads(line)
        if 'error' in value:raise RuntimeError(self.name+': '+value['error'])
        return value
    def request(self,req):
        self.p.stdin.write(json.dumps(req)+'\n');self.p.stdin.flush();value=self.read()
        if value.get('id')!=req['id']:raise ValueError('worker response id mismatch')
        return value
    def close(self):
        try:
            if self.p.poll() is None:
                try:self.p.stdin.write('quit\n');self.p.stdin.flush();self.p.wait(timeout=10)
                except Exception:self.p.kill();self.p.wait(timeout=5)
        finally:
            for stream in [self.p.stdin,self.p.stdout]:
                if stream:
                    try:stream.close()
                    except Exception:pass
            self.err.close()

def pcm_check(reference,path,exact):
    def read(p):
        data=Path(p).read_bytes()
        if len(data)%4:raise ValueError('malformed PCM')
        v=array.array('f');v.frombytes(data)
        if sys.byteorder!='little':v.byteswap()
        if not v or not all(math.isfinite(x) for x in v):raise ValueError('empty/nonfinite PCM')
        return v
    x,y=read(reference),read(path);same=len(x)==len(y)
    delta=max((abs(float(a)-float(b)) for a,b in zip(x,y)),default=0.0) if same else None
    return {'same_samples':same,'max_abs':delta,'exact_required':exact,'pass':same and (delta==0 if exact else delta<0.02)}

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--previous',type=Path,default=Path('results-kernel-02'))
    p.add_argument('--model',type=Path,default=Path('C:/PiVoTest/models/PiVo-1.4M'))
    p.add_argument('--out',type=Path,required=True)
    p.add_argument('--cycles',type=int,default=2)
    p.add_argument('--repeats',type=int,default=5)
    p.add_argument('--timeout',type=int,default=600)
    p.add_argument('--drift-limit',type=float,default=.10)
    p.add_argument('--background-limit',type=float,default=10.0)
    p.add_argument('--check-only',action='store_true')
    a=p.parse_args()
    if a.cycles<2 or a.cycles>10 or a.cycles%2:p.error('cycles must be even, 2..10, for balanced ABBA/BAAB')
    if not 3<=a.repeats<=30 or not 30<=a.timeout<=3600:p.error('repeats 3..30; timeout 30..3600')
    if not math.isfinite(a.drift_limit) or not 0<a.drift_limit<=1:p.error('drift limit must be >0 and <=1')
    if not math.isfinite(a.background_limit) or not 0<=a.background_limit<=100:p.error('background limit must be 0..100')
    out=a.out.resolve();prev=a.previous.resolve();model=a.model.resolve();here=Path(__file__).resolve().parent
    if out.exists() and any(out.iterdir()):p.error('output must be new or empty')
    out.mkdir(parents=True,exist_ok=True)
    state={'status':'started','adopted':False,'executed':[],'failures':[],'limitations':[
        'Windows x86-64 AVX2/FMA only; not compatibility certification',
        'Persistent workers change harness and code layout, so do not pool with old timings',
        'Three resident engines; only one synthesizes at a time; caches and memory differ from single-engine deployment',
        'Warm repeated short-workload synthesis only; no cold-start, long-limit or server concurrency claim',
        'Background observations are proxies, not thermal/frequency/core-placement diagnosis',
        'No affinity, priority, power plan, kernel or compiler-profile changes',
        'Flags are heuristic; all observations retained; no automatic adoption']}
    workers={};batches=[];blocks=[];refs={};power_snapshots={}
    def save():(out/'status.json').write_text(json.dumps(state,indent=2))
    def command(cmd,log,cwd=None,env=None,required=True):
        with (out/log).open('w',encoding='utf-8') as f:
            result=subprocess.run(list(map(str,cmd)),cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=1800)
        state['executed'].append({'command':list(map(str,cmd)),'returncode':result.returncode,'log':log});save()
        if result.returncode and required:raise RuntimeError('inspect '+log)
        return result.returncode
    def snapshot(label):
        # These read-only queries run between cycles, never inside timed synthesis.
        commands={
            'cpu': ['powershell.exe','-NoProfile','-NonInteractive','-Command',
                'Get-CimInstance Win32_Processor | Select-Object Name,Manufacturer,ProcessorId,NumberOfCores,NumberOfLogicalProcessors,MaxClockSpeed | ConvertTo-Json -Compress'],
            'active-power':['powercfg.exe','/getactivescheme'],
            'power-config':['powercfg.exe','/query']}
        for name,cmd in commands.items():
            try:
                rc=command(cmd,label+'-'+name+'.log',required=False)
                if name in ['active-power','power-config']:
                    power_snapshots.setdefault(label,{})[name]=digest(out/(label+'-'+name+'.log')) if rc==0 else None
            except Exception as e:state.setdefault('telemetry_warnings',[]).append(label+' '+name+': '+str(e))
    save()
    try:
        prior=json.loads((prev/'status.json').read_text())
        if prior.get('source_integrity')!='passed':raise ValueError('previous source integrity did not pass')
        expected={k.replace('\\','/'):v for k,v in json.loads((prev/'source-hashes.json').read_text()).items()}
        if not (here/'case_worker.rs').is_file():raise ValueError('place case_worker.rs next to this script')
        source_hashes={}
        for label in ['baseline','r4a2_vector']:
            tree=prev/('source-'+label)
            if not tree.is_dir():raise ValueError('missing previous source tree '+str(tree))
            for key,value in expected.items():
                if not key.startswith(label+'/'):continue
                rel=key[len(label)+1:];path=tree/rel
                if not path.is_file() or digest(path)!=value:raise ValueError('previous source changed: '+key)
                source_hashes[key]=value
            if label+'/src/cpu.rs' not in source_hashes:raise ValueError('CPU hash absent from previous manifest')
            # Reject unexpected compilable/configuration inputs in the copied source tree.
            for f in tree.rglob('*'):
                if f.is_file() and (f.suffix=='.rs' or f.name in ['Cargo.toml','Cargo.lock','config','config.toml']):
                    key=label+'/'+f.relative_to(tree).as_posix()
                    if key not in expected:raise ValueError('unrecorded build input: '+key)
        (out/'preserved-source-hashes.json').write_text(json.dumps(source_hashes,indent=2))
        sample=json.loads((prev/'app-0-baseline/measurements.json').read_text())
        cases={}
        for row in sample['rows']:
            v={k:row[k] for k in ['case','text','voice','speed','samples']}
            if row['case'] in cases and cases[row['case']]!=v:raise ValueError('inconsistent case manifest')
            cases[row['case']]=v
        if len(cases)!=24:raise ValueError('expected previous successful 24-case workload')
        schedule=design(list(cases.values()),a.cycles,49137)
        (out/'schedule.json').write_text(json.dumps(schedule,indent=2))
        (out/'case-manifest.json').write_text(json.dumps(list(cases.values()),indent=2))
        state['source_integrity']='passed';state['blocks_planned']=len(schedule)
        state['thresholds']={'rtf_repeat_spread':a.drift_limit,'baseline_control_contrast':a.drift_limit,'idle_host_busy_pct':a.background_limit}
        if a.check_only:
            state['status']='source_checked';return 0
        if os.name!='nt' or platform.machine().lower() not in ['amd64','x86_64']:raise RuntimeError('native Windows x86-64 required')
        if not model.is_dir():raise ValueError('model directory missing')
        if not all(shutil.which(x) for x in ['rustc','cargo']):raise RuntimeError('rustc/cargo missing')
        env=os.environ.copy()
        for key in list(env):
            if key.startswith(('CARGO_TARGET_','CARGO_PROFILE_')) or key in ['RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','CARGO_BUILD_RUSTFLAGS','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','PIVO_CPU_BACKEND','PIVO_EXPECT_CPU_BACKEND']:
                env.pop(key,None)
        env.update({'RUSTFLAGS':'-C target-cpu=x86-64','CARGO_INCREMENTAL':'0','PIVO_CPU_BACKEND':'avx2_fma','PIVO_EXPECT_CPU_BACKEND':'avx2_fma'})
        state['build_flags']=env['RUSTFLAGS']
        for cmd,name in [(['rustc','-Vv'],'rust-version.log'),(['cargo','-V'],'cargo-version.log')]:
            command(cmd,name,env=env)
            if (out/name).read_text().strip()!=(prev/name).read_text().strip():raise RuntimeError('compiler/tool version differs from measured run: '+name)
        # Model hashes must match the successful previous experiment.
        model_hashes=json.loads((prev/'model-hashes.json').read_text())
        for name,h in model_hashes.items():
            if digest(model/name)!=h:raise ValueError('model changed: '+name)
        (out/'model-hashes.json').write_text(json.dumps(model_hashes,indent=2))
        telemetry=WindowsTelemetry();snapshot('start')
        binaries={}
        for label in ['baseline','r4a2_vector']:
            tree=out/('source-'+label)
            shutil.copytree(prev/('source-'+label),tree)
            (tree/'examples/case_worker.rs').write_bytes((here/'case_worker.rs').read_bytes())
            # Cargo manifest/profile/lock and all src files are deliberately unchanged.
            for key,h in source_hashes.items():
                if key.startswith(label+'/') and digest(tree/key[len(label)+1:])!=h:raise ValueError('copy integrity mismatch '+key)
            local=env.copy();local['CARGO_TARGET_DIR']=str(out/('target-'+label))
            print('Building identical harness for',label,flush=True)
            command(['cargo','build','--locked','--release','--example','case_worker','--verbose'],label+'-build.log',tree,local)
            binaries[label]=Path(local['CARGO_TARGET_DIR'])/'release/examples/case_worker.exe'
        state['binary_sha256']={k:digest(v) for k,v in binaries.items()}
        state['harness_sha256']=digest(here/'case_worker.rs')
        for name,label in [('A','baseline'),('B','r4a2_vector'),('C','baseline')]:
            pcm=out/'pcm'/name
            workers[name]=Worker(name,binaries[label],model,pcm,out,env,a.timeout)
        state['control_binary_identical']=True
        state['worker_pids']={k:v.p.pid for k,v in workers.items()}
        previous_cycle=None
        raw=(out/'batches.jsonl').open('w',encoding='utf-8');blocklog=(out/'blocks.jsonl').open('w',encoding='utf-8')
        try:
            for bi,plan in enumerate(schedule):
                if plan['cycle']!=previous_cycle:
                    snapshot('cycle-'+str(plan['cycle']));previous_cycle=plan['cycle']
                case=plan['case'];kind=plan['kind'];other='B' if kind=='candidate' else 'C'
                print(f"Block {bi+1}/{len(schedule)}: {case['case']} {kind} {plan['pattern']}",flush=True)
                pre=telemetry.idle_observation();sys0=telemetry.system();wall0=time.perf_counter()
                cpu0={name:telemetry.process(worker.p.pid) for name,worker in workers.items()}
                current=[]
                for pos,letter in enumerate(plan['pattern']):
                    name='A' if letter=='A' else other;worker=workers[name];request_id=len(batches)
                    req={'id':request_id,'text':case['text'],'voice':case['voice'],'speed':case['speed'],'repeats':a.repeats,'warmups':2}
                    result=worker.request(req)
                    if len(result['rows'])!=a.repeats or any(row['samples']!=case['samples'] for row in result['rows']):raise ValueError('unexpected sample/repetition count')
                    path=worker.pcm/result['pcm']
                    # Every case must first acquire an A reference even if pattern starts B.
                    batch={'id':request_id,'block':bi,'cycle':plan['cycle'],'case':case['case'],'kind':kind,'pattern':plan['pattern'],'position':pos,'letter':letter,'worker':name,
                        'rows':result['rows'],'summary':batch_summary(result['rows']),'pcm_path':str(path)}
                    batches.append(batch);current.append(batch)
                    # Flush raw data immediately, including incomplete blocks on failure.
                    raw.write(json.dumps(batch)+'\n');raw.flush()
                if case['case'] not in refs:refs[case['case']]=next(Path(x['pcm_path']) for x in current if x['worker']=='A')
                for batch in current:
                    batch['numerical']=pcm_check(refs[case['case']],batch['pcm_path'],batch['worker'] in ['A','C'])
                sys1=telemetry.system();wall=time.perf_counter()-wall0
                cpu1={name:telemetry.process(worker.p.pid) for name,worker in workers.items()}
                post=telemetry.idle_observation()
                process_cpu={name:cpu1[name]-cpu0[name] if cpu1[name] is not None and cpu0[name] is not None else None for name in workers}
                system_delta=(sys1['total']-sys0['total']) if sys0 and sys1 else None
                host_busy_pct=None;nonworker_pct=None
                if system_delta and system_delta>0:
                    busy_seconds=max(0,system_delta-(sys1['idle']-sys0['idle']))
                    host_busy_pct=100*busy_seconds/system_delta
                    if all(v is not None for v in process_cpu.values()):
                        nonworker_pct=100*max(0,busy_seconds-sum(process_cpu.values()))/system_delta
                analysis=block_analysis(current,kind,a.drift_limit,a.drift_limit,a.background_limit,pre,post)
                block={'block':bi,'cycle':plan['cycle'],'case':case['case'],'kind':kind,'pattern':plan['pattern'],
                    'batch_ids':[x['id'] for x in current],'before':pre,'after':post,'wall_seconds_including_warmup_io':wall,
                    'worker_cpu_seconds':process_cpu,'during_block_host_busy_pct':host_busy_pct,'during_block_nonworker_pct_including_python_io':nonworker_pct,'system_cpu_before':sys0,'system_cpu_after':sys1,**analysis}
                blocks.append(block);blocklog.write(json.dumps(block)+'\n');blocklog.flush()
                state['blocks_completed']=len(blocks);save()
        finally:raw.close();blocklog.close()
        snapshot('end')
        (out/'power-snapshot-hashes.json').write_text(json.dumps(power_snapshots,indent=2))
        start_power=power_snapshots.get('start',{})
        session_power_changed=any(start_power.get(k)!=power_snapshots.get('end',{}).get(k) for k in ['active-power','power-config'])
        for block in blocks:
            cycle_power=power_snapshots.get('cycle-'+str(block['cycle']),{})
            if session_power_changed or any(start_power.get(k)!=cycle_power.get(k) for k in ['active-power','power-config']):
                block['flags'].append('power_configuration_changed');block['unstable']=True
            if any(start_power.get(k) is None or cycle_power.get(k) is None for k in ['active-power','power-config']):
                block['flags'].append('power_configuration_unavailable');block['unstable']=True
        # Link control instability to its neighboring candidate block, never discard it.
        controls={(x['cycle'],x['case']):x for x in blocks if x['kind']=='control'}
        for block in blocks:
            if block['kind']=='candidate':
                control=controls[(block['cycle'],block['case'])]
                block['control_block']=control['block']
                if control['unstable']:
                    block['flags'].append('paired_baseline_control_flagged');block['unstable']=True
        summary={}
        for kind in ['candidate','control']:
            selected=[b for b in blocks if b['kind']==kind]
            def summarize(subset):
                return {m:{'median_ratio':statistics.median(x['ratios'][m] for x in subset),
                    'median_change_pct':100*(statistics.median(x['ratios'][m] for x in subset)-1),
                    'wins':sum(x['ratios'][m]<1 for x in subset),'blocks':len(subset),
                    'worst_ratio':max(x['ratios'][m] for x in subset)} for m in METRICS} if subset else {}
            summary[kind]={'all_blocks_primary':summarize(selected),'flagged_blocks':sum(x['unstable'] for x in selected),
                'unflagged_secondary_only':summarize([x for x in selected if not x['unstable']]),
                'warning':'Descriptive block ratios, not independent samples or confidence intervals; all blocks remain in primary analysis'}
        (out/'blocks.json').write_text(json.dumps(blocks,indent=2))
        (out/'summary.json').write_text(json.dumps(summary,indent=2))
        (out/'numerical-checks.json').write_text(json.dumps([{'id':b['id'],'worker':b['worker'],'case':b['case'],**b['numerical']} for b in batches],indent=2))
        with (out/'batch-summary.csv').open('w',newline='') as f:
            fields=['id','block','cycle','case','kind','pattern','position','letter','worker',*METRICS]
            writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader()
            for b in batches:writer.writerow({**{k:b[k] for k in fields if k in b},**b['summary']})
        if any(not b['numerical']['pass'] for b in batches):state['failures'].append('numerical mismatch; no adoption')
        state['status']='failed' if state['failures'] else 'case_blocks_collected'
        state['flagged_blocks']=sum(b['unstable'] for b in blocks)
        state['notes']='No observations discarded. Review all-block results, control contrast, order effects and per-case regressions before adoption.'
    except BaseException as e:
        state['status']='failed';state['failures'].append(type(e).__name__+': '+str(e))
    finally:
        for worker in workers.values():
            try:worker.close()
            except Exception:pass
        save()
        # Package all raw measurements and telemetry, not source/binaries/PCM.
        with zipfile.ZipFile(out/'case-results-upload.zip','w',zipfile.ZIP_DEFLATED) as z:
            for f in out.iterdir():
                if f.is_file() and f.suffix in ['.json','.jsonl','.csv','.log']:z.write(f,f.name)
        print(json.dumps(state,indent=2));print('Upload:',out/'case-results-upload.zip')
    return 1 if state['failures'] else 0
if __name__=='__main__':sys.exit(main())
