#!/usr/bin/env python3
"""Create an isolated, reversible integration repo and validate actual CLI/server."""
import argparse,array,difflib,hashlib,http.client,io,json,math,os,platform,re,shutil,socket,struct,subprocess,sys,time,wave,zipfile
from pathlib import Path
BRANCH='integration/r4a2-vector'

def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda:f.read(1048576),b''):h.update(chunk)
    return h.hexdigest()
def function_span(text):
    module=text.index('mod avx2_fma {')
    start=text.index('pub(super) unsafe fn matvec_into(',module)
    brace=text.index('{',start);end=brace+1;depth=1
    while depth:
        if end>=len(text):raise ValueError('unterminated matvec function')
        depth+=(text[end]=='{')-(text[end]=='}');end+=1
    return start,end
def only_matvec_changed(base,candidate):
    a,b=function_span(base);c,d=function_span(candidate)
    if base[:a]!=candidate[:c] or base[b:]!=candidate[d:]:raise ValueError('Candidate changes code outside AVX2/FMA matvec')
    if base[a:b]==candidate[c:d]:raise ValueError('No candidate change found')
    return base[a:b],candidate[c:d]
def verify_tree(tree,label,manifest):
    if (tree/'.git').exists():raise ValueError('Expected snapshot without Git metadata: '+str(tree))
    keys={k.replace('\\','/'):v for k,v in manifest.items() if k.replace('\\','/').startswith(label+'/')}
    if label+'/src/cpu.rs' not in keys:raise ValueError('Missing CPU provenance: '+label)
    for key,h in keys.items():
        path=tree/key[len(label)+1:]
        if not path.is_file() or path.is_symlink() or sha(path)!=h:raise ValueError('Source integrity mismatch: '+key)
    for f in tree.rglob('*'):
        if f.is_symlink():raise ValueError('Symlink not permitted: '+str(f))
        if f.is_file() and (f.suffix=='.rs' or f.name in ['Cargo.toml','Cargo.lock','config','config.toml']):
            key=label+'/'+f.relative_to(tree).as_posix()
            if key not in keys:raise ValueError('Unrecorded build input: '+key)
    return keys

def f32_file(path):
    b=Path(path).read_bytes()
    if not b or len(b)%4:raise ValueError('Malformed/empty f32 output')
    v=array.array('f');v.frombytes(b)
    if sys.byteorder!='little':v.byteswap()
    if not all(math.isfinite(x) for x in v):raise ValueError('Nonfinite audio')
    return v

def wav_info(data):
    with wave.open(io.BytesIO(data),'rb') as w:
        if w.getnchannels()!=1 or w.getsampwidth()!=2 or w.getnframes()==0:raise ValueError('Expected nonempty mono PCM16 WAV')
        return {'sample_rate':w.getframerate(),'samples':w.getnframes(),'pcm':w.readframes(w.getnframes())}

def check_wav_stream(wav_path,pcm_path):
    info=wav_info(Path(wav_path).read_bytes());raw=f32_file(pcm_path)
    if info['samples']!=len(raw):raise ValueError('CLI stream/buffer sample count mismatch')
    values=array.array('h');values.frombytes(info['pcm'])
    if sys.byteorder!='little':values.byteswap()
    # Rust WAV output quantizes f32 to PCM16; tolerate one LSB for rounding differences.
    largest=0
    for x,y in zip(raw,values):
        z=max(-1.0,min(1.0,float(x)))*32767.0
        expected=math.floor(z+.5) if z>=0 else math.ceil(z-.5)
        largest=max(largest,abs(expected-y))
    if largest>1:raise ValueError('CLI buffered/streamed output differs beyond PCM16 rounding')
    return {'samples':len(raw),'sample_rate':info['sample_rate'],'max_pcm16_lsb_difference':largest}

def compare_pcm(a,b):
    x,y=f32_file(a),f32_file(b)
    if len(x)!=len(y):raise ValueError('Baseline/candidate sample count mismatch')
    delta=max(abs(float(u)-float(v)) for u,v in zip(x,y))
    if delta>=.02:raise ValueError('Baseline/candidate audio error exceeds existing threshold')
    return {'samples':len(x),'max_abs':delta,'pass':True}

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--previous',type=Path,default=Path('results-kernel-02'))
    p.add_argument('--references',type=Path,default=Path('reference-check-01'))
    p.add_argument('--model',type=Path,default=Path('C:/PiVoTest/models/PiVo-1.4M'))
    p.add_argument('--out',type=Path,required=True)
    p.add_argument('--prepare-only',action='store_true',help='create local branch and patch only; no Rust execution')
    a=p.parse_args();out=a.out.resolve();prev=a.previous.resolve();refs=a.references.resolve();model=a.model.resolve()
    if any(out==root or root in out.parents for root in [prev,refs,model]):p.error('Output must be outside previous results, reference data and model directories')
    if out.exists() and any(out.iterdir()):p.error('Output must be new or empty; nothing will be overwritten')
    out.mkdir(parents=True,exist_ok=True);repo=out/'repo';logs=out/'logs';logs.mkdir();artifacts=out/'artifacts';artifacts.mkdir()
    state={'status':'started','deployed':False,'production_modified':False,'branch':BRANCH,'executed':[],'failures':[],
        'release_gates_outstanding':['native AArch64 and required OS/mobile execution','restricted/older CPU application execution','minimum Rust toolchain execution','function-scoped disassembly review','perceptual audio listening','near-limit long recurrence; longer smoke input is not limit coverage'],
        'notes':['New local repository reconstructed from measured snapshot, not a branch in the upstream repository','No remote pushes, no existing checkout changes, no new performance benchmark','Smoke timings are not performance evidence']}
    def save():(out/'integration-status.json').write_text(json.dumps(state,indent=2))
    def run(cmd,log,cwd=None,env=None,timeout=1800):
        print('Running:',log,flush=True)
        with (logs/log).open('w',encoding='utf-8') as f:
            rc=subprocess.run(list(map(str,cmd)),cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=timeout).returncode
        state['executed'].append({'command':list(map(str,cmd)),'returncode':rc,'log':'logs/'+log});save()
        if rc:raise RuntimeError('Inspect logs/'+log)
        return (logs/log).read_text(encoding='utf-8',errors='replace')
    save()
    try:
        if not shutil.which('git'):raise RuntimeError('Git is required; no repository was changed')
        prior=json.loads((prev/'status.json').read_text())
        if prior.get('source_integrity')!='passed' or 'r4a2_vector' not in prior.get('shortlist',[]):raise ValueError('Previous candidate provenance missing')
        manifest=json.loads((prev/'source-hashes.json').read_text())
        base_tree=prev/'source-baseline';candidate_tree=prev/'source-r4a2_vector'
        verified={}
        for label,tree in [('baseline',base_tree),('r4a2_vector',candidate_tree)]:verified.update(verify_tree(tree,label,manifest))
        baseline=(base_tree/'src/cpu.rs').read_text();candidate=(candidate_tree/'src/cpu.rs').read_text()
        only_matvec_changed(baseline,candidate)
        # All non-CPU production source, build and test inputs must match.
        for f in base_tree.rglob('*'):
            if f.is_file() and (f.suffix=='.rs' or f.name in ['Cargo.toml','Cargo.lock']):
                rel=f.relative_to(base_tree)
                if rel.as_posix()=='src/cpu.rs':continue
                other=candidate_tree/rel
                if not other.is_file() or f.read_bytes()!=other.read_bytes():raise ValueError('Unexpected non-CPU candidate difference: '+str(rel))
        (out/'source-provenance.json').write_text(json.dumps(verified,indent=2))
        state['baseline_cpu_sha256']=sha(base_tree/'src/cpu.rs');state['candidate_cpu_sha256']=sha(candidate_tree/'src/cpu.rs')
        shutil.copytree(base_tree,repo)
        # Ignore only generated build artifacts. Original source files remain unchanged.
        if not (repo/'.gitignore').exists():(repo/'.gitignore').write_text('/target/\n')
        hooks=out/'disabled-hooks';hooks.mkdir();template=out/'empty-git-template';template.mkdir()
        git_env=os.environ.copy()
        for key in list(git_env):
            if key.startswith('GIT_'):git_env.pop(key,None)
        git=['git','-c','core.autocrlf=false','-c','core.hooksPath='+str(hooks),'-c','commit.gpgsign=false',
            '-c','user.name=PiVo local integration snapshot','-c','user.email=integration@localhost']
        def g(args,name):return run(git+args,name,repo,git_env)
        g(['init','--template='+str(template)],'git-init.log')
        g(['config','--local','core.autocrlf','false'],'git-local-line-endings.log')
        g(['add','--force','--all'],'git-add-baseline.log')
        g(['commit','-m','Preserve measured platform-aware baseline snapshot'],'git-baseline-commit.log')
        g(['branch','-M','baseline-measured'],'git-baseline-branch.log')
        state['baseline_commit']=g(['rev-parse','HEAD'],'git-baseline-id.log').strip()
        g(['checkout','-b',BRANCH],'git-integration-branch.log')
        shutil.copy2(candidate_tree/'src/cpu.rs',repo/'src/cpu.rs')
        changed=g(['diff','--name-only'],'git-change-list.log').splitlines()
        if changed!=['src/cpu.rs']:raise ValueError('Unexpected integration change list: '+str(changed))
        g(['diff','--check'],'git-diff-check.log')
        patch= ''.join(difflib.unified_diff(baseline.splitlines(True),candidate.splitlines(True),fromfile='a/src/cpu.rs',tofile='b/src/cpu.rs'))
        (out/'r4a2-vector.patch').write_text(patch)
        g(['add','--','src/cpu.rs'],'git-add-candidate.log')
        g(['commit','-m','Integrate tested AVX2 FMA vector reduction only'],'git-candidate-commit.log')
        state['candidate_commit']=g(['rev-parse','HEAD'],'git-candidate-id.log').strip()
        if g(['status','--porcelain'],'git-clean.log').strip():raise ValueError('Integration repository unexpectedly dirty')
        state['integration_created']=True;save()
        if a.prepare_only:
            state['status']='branch_prepared_not_built';return 0
        if os.name!='nt' or platform.machine().lower() not in ['amd64','x86_64']:raise RuntimeError('Actual application validation currently targets native Windows x86-64')
        if not all(shutil.which(x) for x in ['rustc','cargo']):raise RuntimeError('rustc/cargo missing; branch preserved but not validated')
        if not model.is_dir():raise ValueError('Model directory missing')
        for name,h in json.loads((prev/'model-hashes.json').read_text()).items():
            if sha(model/name)!=h:raise ValueError('Model changed: '+name)
        reference_state=json.loads((refs/'status.json').read_text())
        if reference_state.get('status')!='reference_checks_passed' or reference_state.get('failures'):raise ValueError('Prior independent reference matrix did not pass')
        ref_cases=[]
        for ti in range(3):
            for vi in range(2):
                for si in range(3):
                    name=f't{ti}_v{vi}_s{si}';rd=refs/name
                    for file in ['case.json','tokens.bin','encoded.bin','log_durations.bin','expanded.bin','features.bin','audio.bin']:
                        if not (rd/file).is_file() or not (rd/file).stat().st_size:raise ValueError('Reference file missing/empty: '+str(rd/file))
                    case=json.loads((rd/'case.json').read_text())
                    if not case.get('text') or not case.get('voice') or case.get('speed') not in [.5,1.0,2.0]:raise ValueError('Invalid reference manifest')
                    ref_cases.append((name,rd))
        (out/'reference-hashes.json').write_text(json.dumps({f.relative_to(refs).as_posix():sha(f) for _,rd in ref_cases for f in rd.iterdir() if f.is_file()},indent=2))
        env=os.environ.copy()
        for key in list(env):
            if key.startswith(('CARGO_TARGET_','CARGO_PROFILE_')) or key in ['RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','CARGO_BUILD_RUSTFLAGS','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','PIVO_CPU_BACKEND','PIVO_EXPECT_CPU_BACKEND','PIVO_MODEL','PIVO_MODEL_DIR','PIVO_REF_DIR','PIVO_REQUIRE_REFERENCE','PIVO_API_KEY','PIVO_HOST','PIVO_PORT']:
                env.pop(key,None)
        env.update({'RUSTFLAGS':'-C target-cpu=x86-64','CARGO_INCREMENTAL':'0','PIVO_MODEL_DIR':str(model)})
        for cmd,log in [(['rustc','-Vv'],'rust-version.log'),(['cargo','-V'],'cargo-version.log')]:
            text=run(cmd,log,env=env)
            if text.strip()!=(prev/log).read_text().strip():raise ValueError('Compiler/tool version changed: '+log)
        state['build_flags']=env['RUSTFLAGS']
        # Build actual application on baseline branch, then integration branch; separate target dirs.
        executables={}
        for label,branch in [('baseline','baseline-measured'),('candidate',BRANCH)]:
            g(['checkout',branch],'git-checkout-'+label+'.log')
            local=env.copy();local['CARGO_TARGET_DIR']=str(out/('target-'+label))
            local['PIVO_CPU_BACKEND']='avx2_fma';local['PIVO_EXPECT_CPU_BACKEND']='avx2_fma'
            run(['cargo','test','--locked','--release','--lib','--bins','--test','frontend'],label+'-application-tests.log',repo,local)
            run(['cargo','build','--locked','--release','--bin','pivo-studio'],label+'-application-build.log',repo,local)
            built=Path(local['CARGO_TARGET_DIR'])/'release/pivo-studio.exe'
            destination=artifacts/label;destination.mkdir();shutil.copy2(built,destination/'pivo-studio.exe')
            executables[label]=destination/'pivo-studio.exe'
        # Candidate remains checked out; rerun all 18 independent reference cases against integration repo.
        for name,rd in ref_cases:
            local=env.copy();local.update({'CARGO_TARGET_DIR':str(out/'target-candidate'),'PIVO_CPU_BACKEND':'avx2_fma','PIVO_EXPECT_CPU_BACKEND':'avx2_fma','PIVO_REF_DIR':str(rd),'PIVO_REQUIRE_REFERENCE':'1'})
            text=run(['cargo','test','--locked','--release','--test','numerics','--','--nocapture'],name+'-integrated-reference.log',repo,local)
            if not re.search(r'test result: ok\. 3 passed; 0 failed;',text) or 'skipping:' in text:raise ValueError('Reference test count/skip guard failed: '+name)
        state['integrated_reference_cases_passed']=18
        # Real CLI synthesis and streaming, not benchmark examples.
        sample=json.loads((prev/'app-0-baseline/measurements.json').read_text())
        voices=sorted({x['voice'] for x in sample['rows']})
        smoke=[]
        for voice in voices:
            for speed in [.5,1.0,2.0]:smoke.append({'id':f'short-{len(smoke)}','text':'NASA is ready for the next mission.','voice':voice,'speed':speed})
        smoke.extend([
            {'id':'longer-single-clause','text':' '.join(['The quick brown fox jumps over the lazy dog']*4),'voice':voices[0],'speed':1.0},
            {'id':'multi-clause','text':'The quick brown fox jumps over the lazy dog. '*12,'voice':voices[0],'speed':1.0}])
        (out/'smoke-cases.json').write_text(json.dumps(smoke,indent=2));checks=[]
        for label,exe in executables.items():
            local=env.copy();local['PIVO_CPU_BACKEND']='auto'
            run([exe,'--help'],label+'-cli-help.log',env=local)
            run([exe,'voices','--model',model],label+'-cli-voices.log',env=local)
            for case in smoke:
                dest=out/'audio'/label;dest.mkdir(parents=True,exist_ok=True)
                wav=dest/(case['id']+'.wav');pcm=dest/(case['id']+'.f32')
                common=['--model',model,'--text',case['text'],'--voice',case['voice'],'--speed',case['speed']]
                run([exe,'synthesize',*common,'--output',wav],label+'-'+case['id']+'-synthesize.log',env=local)
                run([exe,'stream',*common,'--dump-pcm',pcm],label+'-'+case['id']+'-stream.log',env=local)
                checks.append({'variant':label,'case':case['id'],'type':'buffered-streamed',**check_wav_stream(wav,pcm)})
        for case in smoke:
            checks.append({'case':case['id'],'type':'candidate-baseline',**compare_pcm(out/'audio/baseline'/(case['id']+'.f32'),out/'audio/candidate'/(case['id']+'.f32'))})
        # Portable fallback smoke on candidate; not a restricted-CPU compatibility proof.
        portable=out/'audio/portable';portable.mkdir()
        case=smoke[0];local=env.copy();local['PIVO_CPU_BACKEND']='portable'
        run([executables['candidate'],'stream','--model',model,'--text',case['text'],'--voice',case['voice'],'--speed',case['speed'],'--dump-pcm',portable/'smoke.f32'],'candidate-portable-smoke.log',env=local)
        checks.append({'type':'portable-vs-auto','case':case['id'],**compare_pcm(portable/'smoke.f32',out/'audio/candidate'/(case['id']+'.f32'))})
        (out/'application-audio-checks.json').write_text(json.dumps(checks,indent=2))
        # HTTP smoke: loopback only, no browser, no firewall changes, no remote calls.
        def request(port,method,path,body=None):
            conn=http.client.HTTPConnection('127.0.0.1',port,timeout=120)
            try:
                payload=json.dumps(body) if body is not None else None
                conn.request(method,path,body=payload,headers={'Content-Type':'application/json'} if payload else {})
                response=conn.getresponse();data=response.read()
                if response.status!=200:raise ValueError(f'HTTP {response.status} for {path}: '+data[:200].decode(errors='replace'))
                return data
            finally:conn.close()
        for label,exe in executables.items():
            with socket.socket() as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
            local=env.copy();local['PIVO_CPU_BACKEND']='auto'
            log=(logs/(label+'-server.log')).open('w',encoding='utf-8');process=None
            try:
                process=subprocess.Popen(list(map(str,[exe,'serve','--model',model,'--host','127.0.0.1','--port',port,'--max-concurrent',1])),env=local,stdout=log,stderr=subprocess.STDOUT)
                deadline=time.monotonic()+90
                while True:
                    if process.poll() is not None:raise RuntimeError('Server exited: '+label)
                    try:
                        health=json.loads(request(port,'GET','/health'))
                        if health.get('status')!='ready':raise ValueError('Server not ready')
                        break
                    except (OSError,http.client.HTTPException):
                        if time.monotonic()>deadline:raise RuntimeError('Server startup timeout')
                        time.sleep(.2)
                if process.poll() is not None:raise RuntimeError('Server exited during startup')
                # A narrow port-selection race remains; verify model output against the CLI.
                voices_result=json.loads(request(port,'GET','/v1/voices'))
                if not voices_result.get('voices'):raise ValueError('Empty server voices')
                case=smoke[0];data=request(port,'POST','/v1/audio/speech',{'input':case['text'],'voice':case['voice'],'speed':case['speed'],'response_format':'wav'})
                info=wav_info(data);cli=wav_info((out/'audio'/label/(case['id']+'.wav')).read_bytes())
                if info!=cli:raise ValueError('HTTP and CLI WAV output mismatch')
                (out/(label+'-http-health.json')).write_text(json.dumps(health,indent=2))
                (out/(label+'-http-voices.json')).write_text(json.dumps(voices_result,indent=2))
                state.setdefault('http_smoke',{})[label]='passed on loopback'
            finally:
                if process is not None and process.poll() is None:
                    process.terminate()
                    try:process.wait(timeout=10)
                    except subprocess.TimeoutExpired:process.kill();process.wait(timeout=5)
                log.close()
        if sha(repo/'src/cpu.rs')!=state['candidate_cpu_sha256']:raise ValueError('Integrated CPU source changed during validation')
        if g(['status','--porcelain'],'git-final-clean.log').strip():raise ValueError('Unexpected working tree modifications')
        state['binary_sha256']={k:sha(v) for k,v in executables.items()}
        state['status']='controlled_integration_validated_not_released'
        state['listen_to']=[str(out/'audio/candidate'/('short-0.wav')),str(out/'audio/candidate/multi-clause.wav')]
        state['rollback']='Use artifacts/baseline/pivo-studio.exe; source branch baseline-measured remains available'
    except BaseException as e:state['status']='failed';state['failures'].append(type(e).__name__+': '+str(e))
    finally:
        save()
        with zipfile.ZipFile(out/'integration-results-upload.zip','w',zipfile.ZIP_DEFLATED) as z:
            for f in out.iterdir():
                if f.is_file() and f.suffix in ['.json','.patch']:z.write(f,f.name)
            for f in logs.glob('*.log'):z.write(f,'logs/'+f.name)
        print(json.dumps(state,indent=2));print('Upload:',out/'integration-results-upload.zip')
    return 1 if state['failures'] else 0
if __name__=='__main__':sys.exit(main())
