> **Superseded in part.** The kernel speedup figures here (5.26x to 7.03x) come from an early, less carefully timed run. The calibrated run gives about 4.9x to 7.9x. See PiVo_Implementation_Checklist_and_Prompt.md and CORRECTIONS.md.

# PiVo Studio: AVX2/FMA matrix-vector optimization

**Date:** 2026-11-04  
**Candidate:** `r4a2_vector`  
**Integration branch:** `integration/r4a2-vector`  
**Status:** Controlled local integration validated; not released or deployed.

## 1. Executive summary

This work optimizes the final accumulation/reduction step of the AVX2/FMA matrix-vector kernel used by PiVo Studio. The selected candidate retains four-output-row blocking and two vector accumulators per output row, but replaces scalar lane accumulation through a temporary array with a vector reduction.

Two per-case benchmark sessions on an Intel Core Ultra 7 165U running Windows 11 reported **8.17% and 7.33% lower median real-time-factor ratios** relative to the already optimized, platform-aware baseline. The second session also reported 3.76% lower median time-to-first-audio ratio, 5.91% lower frame-p95 ratio, and 6.05% lower frame-p99 ratio.

These are descriptive benchmark results for one machine, one model and a bounded workload. They are not universal speed guarantees, pooled request percentiles, or performance measurements of the final integrated application executable. Timing instability remains documented rather than removed from the analysis.

The integrated application passed its library/frontend tests, 18 independent-reference cases, real CLI buffered/streamed synthesis checks, a portable-override smoke check, and loopback HTTP smoke checks. Older CPUs, AArch64, other required platforms, minimum-toolchain coverage, disassembly review, perceptual listening and near-limit recurrence remain release gates.

## 2. Critical scope distinction

### 2.1 What the final integration commit changes

The final integration commit changes **one production source file**:

```text
src/cpu.rs
```

The change is confined to:

```text
avx2_fma::matvec_into
```

Recorded Git summary:

```text
1 file changed, 19 insertions(+), 24 deletions(-)
```

The integration helper verified that the baseline and candidate CPU modules differ only inside that function. It also checked that the other Rust source, tests, Cargo manifest and lockfile match between the measured baseline and candidate snapshots.

### 2.2 What this is NOT a diff against

The measured baseline already contains earlier platform-aware CPU work, including a CPU module, runtime dispatch and specialized/fallback implementations. The final commit is **not** the complete diff from an arbitrary upstream PiVo Studio checkout to that platform-aware baseline.

Do not describe this final one-function patch as introducing every CPU backend or all earlier model-to-kernel refactoring. Those are baseline prerequisites, not changes made by the final integration commit.

If the GitHub branch does not already contain the measured baseline architecture, review and port the prerequisite changes separately. Applying the final patch blindly to unrelated upstream code is not appropriate.

### 2.3 Exact source authority

The authoritative exact source change is the local Git diff and generated patch:

```text
integration-01/r4a2-vector.patch
integration-01/repo: baseline-measured..integration/r4a2-vector
```

The archive's text representation exposes the file/function scope, Git statistics and provenance, but does not preserve every added/deleted patch line. Consequently, the code excerpt below explains the selected reduction algorithm; it is **not presented as a byte-for-byte replacement for the complete patch**. Use the local Git diff when importing the exact change.

## 3. Production change: technical details

### 3.1 Matrix-vector operation

The kernel computes a row-major matrix-vector product:

```text
y[row] = sum(w[row * in_dim + k] * x[k], k = 0 .. in_dim)
```

Inputs remain dynamically dimensioned. There is no hard-coded dependency on the profiled matrix sizes.

### 3.2 Baseline structure retained

The selected candidate retains:

- Four output rows processed together in the main row block.
- Two 256-bit accumulators per output row.
- Eight `f32` lanes per 256-bit vector.
- FMA-based vector accumulation.
- The existing 16-element main input step and 8-element vector remainder handling.
- Unaligned vector loads.
- Scalar handling for remaining input elements.
- Existing handling of output rows outside a complete four-row block.
- Input/output/matrix shape validation, including checked dimension multiplication.
- Zero-width handling that fills output with zero.
- Existing runtime ISA detection and dispatch.

The experiment name `r4a2_vector` means four rows, two accumulators per row, vector-based final reduction. Four-row blocking and two accumulators were already present in the measured baseline; they are not new benefits to attribute to this final patch.

### 3.3 Reduction before the change

The baseline reduces the vector accumulators using a temporary eight-element lane array and scalar accumulation. Conceptually, for each output row:

1. Store one vector accumulator into temporary scalar lanes.
2. Accumulate those lanes into a scalar sum.
3. Repeat for the second accumulator.
4. Add any scalar input tail.
5. Store the output row value.

This describes the source-level strategy. It does not prove the compiler emitted literal stack stores or quantify instruction-level savings. That requires disassembly inspection.

### 3.4 Reduction after the change

The candidate:

1. Adds the two 256-bit accumulators lane by lane.
2. Adds the upper and lower 128-bit halves.
3. Performs two horizontal additions within the resulting 128-bit vector.
4. Extracts the scalar result.
5. Adds the existing scalar tail.
6. Stores the output row value.

Representative reduction for one row, using the candidate's intrinsic sequence:

```rust
// Explanatory excerpt, not the complete exact patch.
let v = _mm256_add_ps(a0_0, a0_1);
let half = _mm_add_ps(
    _mm256_castps256_ps128(v),
    _mm256_extractf128_ps::<1>(v),
);
let pairs = _mm_hadd_ps(half, half);
let mut sum = _mm_cvtss_f32(_mm_hadd_ps(pairs, pairs));

// The existing scalar input tail is then accumulated into sum.
```

The same reduction structure is applied to the other output rows in the four-row block. The safety comment was clarified to refer to checked full-vector/tail bounds and AVX2/FMA dispatch checks. Source-level formatting changes within the function are included in the recorded Git line statistics.

### 3.5 Why this may improve performance

The intended improvement is reducing scalar work and dependency length in the final vector-to-scalar reduction, while leaving the main matrix access and FMA accumulation structure intact.

This is a mechanism hypothesis consistent with the benchmark improvement, not a measured attribution of cycles. No completed function-scoped assembly or hardware-counter analysis establishes the exact cause of the speedup.

### 3.6 Floating-point implications

The reduction order changes. Floating-point addition is not associative, so the candidate is not expected to be bit-identical to the baseline.

For example, adding corresponding lanes from two accumulators before horizontal reduction is not numerically identical to serially summing all lanes of the first accumulator and then all lanes of the second.

The work therefore validates:

- Finite output.
- Equal output lengths.
- Candidate/baseline numerical differences.
- Independent encoder, duration, decoder and audio references.
- Buffered/streamed application output agreement.

Passing these tests supports the tested cases; it does not establish mathematical equivalence for all inputs or perceptual equivalence.

## 4. What did not change in the final integration

| Area | Final integration change |
|---|---|
| Runtime CPU detection/dispatch | None |
| Portable, SSE2, AVX, AVX/FMA, AVX-512 and NEON implementations outside the target function | None |
| Model weights, ONNX files and model format | None |
| Model architecture or training | None |
| Tokenization, pronunciation and text normalization | None |
| Voice definitions and speed options | None |
| CLI/API/Web Studio behavior | None |
| Cargo dependencies, manifest and lockfile | None |
| Release compiler profile and target flags | None |
| Existing numerical thresholds | None |
| Shape-aware dispatcher experiment | Not integrated |
| Weight packing, operation fusion or scratch-buffer redesign | Not implemented |

Tests and benchmark tools described below are supporting experiment infrastructure. They are not additional production-code changes in the final one-file commit.

## 5. Profiling and experiment selection

### 5.1 Workload-driven profiling

A separate diagnostic build counted public matrix-vector calls and sampled their execution time. The recorded workload contained 3,254,232 calls across 21 shapes. The six highest-cost shapes accounted for approximately 68.68% of estimated public matrix-vector time:

| Output rows × input width | Calls | Estimated matrix-vector time share |
|---|---:|---:|
| 480 × 272 | 164,172 | 15.58% |
| 384 × 128 | 328,344 | 12.66% |
| 384 × 240 | 164,172 | 11.30% |
| 384 × 208 | 164,172 | 9.89% |
| 480 × 160 | 164,172 | 9.78% |
| 128 × 688 | 164,172 | 9.47% |

These percentages estimate **public matrix-vector time**, not whole-application CPU time. Instrumentation changes timing/cache conditions and was disabled in performance builds.

The only observed width below 32 was 96 × 4, at approximately 0.13% of estimated matrix-vector time. Widths 8–31 did not appear. This made narrow-input dispatcher tuning a poor target for this workload.

### 5.2 Candidates evaluated

| Candidate | Experiment | Final disposition |
|---|---|---|
| `r2a2` | Two rows, two accumulators per row | Not integrated |
| `r4a1` | Four rows, one accumulator per row | Not integrated |
| `r8a1` | Eight rows, one accumulator per row | Advanced to application screening, not integrated |
| `r4a2_vector` | Existing four-row/two-accumulator structure with vector reduction | Selected and integrated locally |
| `r4a2_unroll2` | More-unrolled main loop | Not integrated |
| Earlier shape-aware dispatcher | Portable/SSE2 selection for narrow shapes | Rejected after application regressions |

The screening used the observed priority shapes, hot-weight tests and rotating-weight tests. A kernel-only win was not sufficient for adoption.

## 6. Benchmark environment

| Property | Recorded value |
|---|---|
| CPU | Intel Core Ultra 7 165U |
| Physical cores / logical processors | 12 / 14 |
| OS | Windows 11, x86-64 |
| Active Windows power scheme | Balanced |
| Model | PiVo-1.4M |
| Voices | Pi and Vo |
| Speeds | 0.5, 1.0 and 2.0 |
| Rust | 1.99.1, commit 58cf8f9c3, 2026-10-13 |
| Cargo | 1.99.1, commit 5f94df478, 2026-08-27 |
| Rust host | x86_64-pc-windows-msvc |
| LLVM | 23.1.1 |
| RUSTFLAGS | `-C target-cpu=x86-64` |
| Build mode | Locked release build |
| Measured specialized backend | AVX2/FMA |

This was not the Legion/Ultra 9 machine. CPU model metadata such as MaxClockSpeed is not a measurement of the actual operating frequency during synthesis.

No affinity, priority or power-plan changes were made by the per-case benchmark helper. It does not diagnose thermal throttling, hybrid-core placement or frequency behavior.

## 7. Benchmark methodology

### 7.1 Workload

The per-case workload contains four texts, two voices and three speeds: 24 cases. The texts cover a short sentence, a number sequence, a repeated single clause and a multi-clause document. Oversized earlier test inputs were shortened after hitting the model's 3,000-frame limit. The limit itself was not raised.

Each per-case session used:

- Two cycles.
- Both ABBA and BAAB order for every case.
- 48 candidate blocks and 48 baseline-control blocks.
- Four batches per block.
- Five measured synthesis requests per batch.
- Two excluded warmups per batch.
- 1,920 measured requests per session, including control requests.

### 7.2 Worker definitions

- **A:** baseline executable, first worker.
- **B:** candidate executable.
- **C:** a second instance of the exact same baseline executable as A.

Candidate blocks use ABBA/BAAB. Control blocks use ACCA/CAAC. Only one worker synthesizes at a time, but all three model instances remain resident. This changes memory/cache conditions relative to a single-engine deployment.

### 7.3 Reported statistic

For each batch, request RTF and TTFA are summarized by their medians. Frame p95/p99 are computed from frame observations in that batch.

For each block and metric:

```text
block_ratio = median(two B batch summaries) / median(two A batch summaries)
```

For controls, B denotes the second baseline worker C rather than the candidate.

The primary result is the median of these ratios across all blocks of that type:

```text
reported_change_percent = 100 × (median(block_ratios) - 1)
```

Lower is better. These are not pooled request percentiles, total-wall-time ratios or formal confidence intervals. Repeated cases/cycles are not all statistically independent.

RTF is synthesis time divided by generated audio duration. Lower RTF indicates less synthesis time for the same audio duration. A percentage reduction in time should not be casually relabeled as the same percentage increase in throughput.

### 7.4 Instability handling

All observations remain in the primary analysis. Flags identify repeated-batch drift, baseline-control contrast, background activity and power-state/configuration issues. A separately labeled unflagged-only summary is diagnostic, not the headline result.

No thresholds were raised to make the candidate pass. Idle host-busy observations are proxies and do not identify a specific background process. A later five-second sample showed Notepad consuming approximately one logical processor, but does not prove its activity during every prior benchmark.

## 8. Performance results

### 8.1 Primary per-case results

Negative changes mean lower time/ratio and are favorable.

| Metric | Session 1: `case-blocks-01` | Session 2: `case-blocks-02` |
|---|---:|---:|
| Median RTF ratio change | **-8.1708%** | **-7.3279%** |
| Median TTFA ratio change | -4.1585% | -3.7597% |
| Median frame-p95 ratio change | -8.7596% | -5.9130% |
| Median frame-p99 ratio change | -6.0233% | -6.0538% |
| RTF winning candidate blocks | 38 / 48 | 37 / 48 |
| Frame-p95 winning candidate blocks | 40 / 48 | 40 / 48 |
| Median identical-baseline RTF contrast | -1.0795% | -0.6924% |
| Flagged candidate blocks | 48 / 48 | 46 / 48 |
| Flagged control blocks | 47 / 48 | 43 / 48 |

Do not pool these session medians into a new overall estimate. They are separate descriptive results.

### 8.2 Second-session exact ratios and regressions

| Metric | Median candidate/baseline ratio | Wins | Worst block ratio |
|---|---:|---:|---:|
| RTF p50 | 0.9267206673 | 37 / 48 | 1.1716869474 |
| TTFA p50 | 0.9624029252 | 28 / 48 | 1.2286257803 |
| Frame p95 | 0.9408696415 | 40 / 48 | 1.3435404197 |
| Frame p99 | 0.9394624410 | 33 / 48 | 1.3406149820 |

The candidate was not faster in every block. The worst RTF block was 17.17% slower and the worst TTFA block was 22.86% slower. These regressions must remain visible.

### 8.3 Second-session control behavior

| Metric | Median identical-baseline ratio | Worst control ratio |
|---|---:|---:|
| RTF p50 | 0.9930757071 | 1.5773426278 |
| TTFA p50 | 1.0203077989 | 1.4275298943 |
| Frame p95 | 0.9938927470 | 1.7886946100 |
| Frame p99 | 0.9976783016 | 1.8284818564 |

A near-one median control ratio does not prove low noise. Positive and negative timing variation can cancel. Large control outliers and many instability flags limit causal certainty.

### 8.4 Instability diagnostics, second session

| Flag | Blocks containing flag |
|---|---:|
| A repeated-batch RTF drift | 47 |
| Paired baseline control flagged | 43 |
| B/C repeated-batch RTF drift | 34 |
| Background busy after block | 31 |
| Background busy before block | 30 |
| Baseline-control contrast | 16 |

Flags overlap and are not independent failures. All 96 blocks remain in the session's primary analysis. Only two candidate blocks were unflagged; their favorable results are not an adequate substitute for the all-block analysis.

### 8.5 Appropriate performance claim

> On a Windows 11 laptop with an Intel Core Ultra 7 165U, the AVX2/FMA vector-reduction candidate reduced the median matched-block real-time-factor ratio by 8.17% and 7.33% in two per-case benchmark sessions using PiVo-1.4M. All blocks, including flagged blocks, were retained. Results are workload- and hardware-specific, and substantial timing variability remained.

Avoid claims such as:

- “PiVo is 8% faster on every CPU.”
- “The final HTTP server is proven 8% faster.”
- “Audio is bit-identical.”
- “All platforms are certified.”
- “The candidate never regresses.”
- “The 7–8% result is a confidence interval.”

## 9. Numerical correctness and application validation

### 9.1 Per-case benchmark numerical checks

Second per-case session:

```text
Total saved-output checks: 384
Failed: 0
Maximum absolute difference: 0.00020200340077280998
```

Each batch saves its first measured output. Baseline/control outputs require exact agreement with the reference baseline for that case. Candidate output uses the existing max-absolute-error threshold below 0.02 and requires equal sample counts. This is not an assertion that all 1,920 requests were independently compared sample by sample.

### 9.2 Independent reference matrix on integrated source

The integration reran 18 saved independent-reference cases:

```text
3 single-clause texts × 2 voices × 3 speeds = 18 cases
```

Each case ran three Rust numerical tests:

1. Encoder output and log-duration comparison.
2. Decoder output comparison.
3. End-to-end audio comparison, including sample counts.

All 18 cases reported three passing tests, with no skipped tests: 54 numerical test executions in the integrated reference matrix. Existing tolerances were not relaxed.

Important distinction: candidate-vs-baseline differences are not the same as candidate-vs-independent-reference differences. For example, the integrated reference log for `t2_v0_s0` reports end-to-end maximum absolute audio difference `4.852e-3`, which passed the existing test. Do not claim the `0.0002020` baseline-comparison maximum also bounds every independent-reference comparison.

The reference generator excludes multi-clause document splitting and retains model-specific assumptions. It does not provide universal ONNX/model equivalence.

### 9.3 Actual application tests

Both baseline and integrated candidate reported:

- Library: 9 passed, 0 failed, 1 ignored manual benchmark.
- Binary unit-test target: 0 tests; successful execution is not additional unit-test coverage.
- Frontend integration tests: 6 passed, 0 failed.

The unused `EPS` warning in `src/model.rs` appeared in both builds and was not addressed by this kernel-only change.

### 9.4 CLI audio checks

Eight smoke cases were exercised for each executable:

- Short sentence, both voices, speeds 0.5 / 1.0 / 2.0: six cases.
- Longer single clause: one case.
- Twelve-clause document: one case.

Checks include:

- 16 buffered-WAV versus streamed-f32 comparisons across both executables.
- Eight candidate-versus-baseline streamed-audio comparisons.
- One candidate portable-override versus auto comparison.

The buffered/streamed comparison allows at most one PCM16 LSB for quantization rounding. This is not a change to the floating-point reference tolerances.

Selected integrated results:

| Case | Samples | Generated duration at 16 kHz | Candidate/baseline max absolute difference |
|---|---:|---:|---:|
| Longer single clause | 156,480 | 9.78 s | 0.00000807643 |
| Twelve-clause document | 493,440 | 30.84 s | 0.00000303984 |

Largest candidate/baseline difference among the eight integrated CLI cases: approximately `0.0001950860`. Portable-versus-auto smoke difference: approximately `0.00000646710`.

These smoke runs establish tested functionality, not a new statistically controlled performance percentage. Their rounded CLI RTF/timing messages must not be used as the primary speed claim.

### 9.5 HTTP smoke checks

Both baseline and candidate servers were started temporarily on loopback and passed:

- `GET /health`.
- `GET /v1/voices`.
- `POST /v1/audio/speech` with WAV output.
- HTTP WAV output comparison with the corresponding CLI output.

The checks do not cover browser UI interaction, HTTP streaming, concurrent server load or network deployment. No firewall changes or production deployment were performed.

## 10. Exact integration provenance

| Artifact | Recorded identifier |
|---|---|
| Baseline branch | `baseline-measured` |
| Integration branch | `integration/r4a2-vector` |
| Baseline local commit | `fe8267c431c2ef135d0a640a1a2405a150f413f6` |
| Candidate local commit | `416d2a734cf8776a3d5503bc620a8c8d1afca5e8` |
| Baseline CPU SHA-256 | `c3a791a4d4ca9886ceb2ba396bf243299ab89bbef0feb8c3f77d79236300e1c5` |
| Candidate CPU SHA-256 | `f04364a897b35fa971e745f06e81aa5a4d7c29184bf666f087aa461b5a0baf74` |
| Baseline integrated executable SHA-256 | `a4a5840f142ee404762cbff03c6c9c6d328c7828491f32a9038859de2e3e6e8d` |
| Candidate integrated executable SHA-256 | `d9ad61b84f67af7fae1dd46c6a040ecf18de8d1175f090c8aa32ae6e5d1654ce` |

These commits belong to a new local repository reconstructed from the measured snapshot. They are not asserted to exist in the upstream GitHub history. The snapshot commits use an explicit local integration identity rather than impersonating an upstream author.

The integration helper reported:

```text
status: controlled_integration_validated_not_released
deployed: false
production_modified: false
```

## 11. Exact diff inspection and GitHub handoff

From the suite directory, inspect the authoritative local change:

```powershell
git -C .\integration-01\repo diff --stat baseline-measured..integration/r4a2-vector

git -C .\integration-01\repo diff baseline-measured..integration/r4a2-vector -- src/cpu.rs

git -C .\integration-01\repo show --format=fuller --stat 416d2a734cf8776a3d5503bc620a8c8d1afca5e8
```

The existing patch is:

```text
integration-01/r4a2-vector.patch
```

For a clean export that avoids PowerShell output-redirection encoding differences:

```powershell
git -C .\integration-01\repo diff --binary --output=../r4a2-vector-git.patch baseline-measured..integration/r4a2-vector -- src/cpu.rs
```

Review against the actual upstream checkout before applying anything. If its baseline is compatible, first run `git apply --check` against the patch from that checkout. Do not copy the entire reconstructed repository over the real project, overwrite unrelated files, or assume these local commit IDs can be cherry-picked without importing their objects/history.

Recommended PR separation:

1. Prerequisite platform-aware CPU changes, only if not already present upstream.
2. The measured one-function AVX2/FMA reduction optimization.
3. Optional benchmark/reference infrastructure in a separate reviewable change.

Do not include model binaries, generated audio, build directories, private environment logs, personal paths or internal SharePoint URLs in a public PR. This report intentionally omits private tenant links and personal machine/user identifiers.

## 12. Supporting tooling created during the work

These tools supported the experiment; they are not all included in the final production commit.

| Tool | Purpose |
|---|---|
| `run_validation.py` | Original baseline/portable/auto comparison runner |
| `run_shape_comparison.py` | Isolated shape-aware dispatch experiment |
| `run_profile.py` and `profile_probe.rs` | Separate count and sampled-timing profiling passes |
| `run_all.py` | Five-candidate kernel screening and application shortlist |
| `generate_reference.py` | Text/voice/speed-parameterized independent reference generation |
| Parameterized `tests/numerics.rs` | Shared case manifests for encoder/decoder/audio checks |
| `resume_validation.py` | Separate reference validation and whole-workload confirmation |
| `run_case_blocks.py` and `case_worker.rs` | Per-case balanced candidate/control benchmarking and telemetry |
| `integrate_candidate.py` | Isolated local branch creation and actual CLI/server validation |

Notable harness corrections and improvements:

- Normalized manifest paths with `as_posix()` to fix Windows backslash hash-key lookups.
- Reduced oversized test text consistently after the 3,000-frame input rejection.
- Kept reference generation separate from performance reruns.
- Replaced whole-workload alternation with per-case ABBA/BAAB blocks.
- Added identical-baseline worker controls and retained every block.
- Added source/model/compiler/binary provenance and read-only power/CPU observations.
- Used Python to report JSON-array checks after PowerShell collection wrapping produced an invalid count of one.

The diagnostic profiling feature was not enabled in performance or integrated application builds. No production change should be inferred merely because a helper script or test was authored during the experiment.

## 13. Reproduction commands

Run from the existing suite directory with its measured snapshots and model available.

### Per-case confirmation

```powershell
.\.venv-validation\Scripts\python.exe .\run_case_blocks.py --previous ".\results-kernel-02" --model "C:\PiVoTest\models\PiVo-1.4M" --out ".\case-blocks-new" --cycles 2 --repeats 5
```

### Controlled integration

```powershell
.\.venv-validation\Scripts\python.exe .\integrate_candidate.py --previous ".\results-kernel-02" --references ".\reference-check-01" --model "C:\PiVoTest\models\PiVo-1.4M" --out ".\integration-new"
```

Use new output directories. Do not overwrite the evidence used for this report.

Actual build commands used by the helper include:

```text
cargo test --locked --release --lib --bins --test frontend
cargo build --locked --release --bin pivo-studio
cargo test --locked --release --test numerics -- --nocapture
```

The helper supplies the required model/reference/backend environment variables, separate target directories and fixed RUSTFLAGS. Running these Cargo commands without that environment is not a complete reproduction of the reference matrix.

## 14. Release checklist

Completed for the tested Windows machine/model:

- [x] Measured baseline preserved.
- [x] Selected kernel change isolated to one function/file.
- [x] Two per-case benchmark sessions with all-block results retained.
- [x] Repeated-baseline controls and instability reporting.
- [x] Second-session 384 saved-output checks passed.
- [x] Real baseline/candidate application builds.
- [x] Library and frontend tests passed.
- [x] Integrated 18-case independent-reference matrix passed.
- [x] CLI buffered/streamed smoke cases passed.
- [x] Longer utterance and multi-clause smoke cases passed.
- [x] Portable override smoke passed on the AVX2-capable machine.
- [x] Loopback HTTP smoke checks passed.
- [x] Clean integration working tree and rollback artifacts retained.

Still outstanding or not reported as completed:

- [ ] Human listening comparison.
- [ ] Browser/Web Studio interaction review.
- [ ] Near-limit long recurrent sequences.
- [ ] Restricted/older CPU execution.
- [ ] Native AArch64 and other required OS/mobile runs.
- [ ] Minimum supported Rust toolchain.
- [ ] Function-scoped disassembly and baseline-path isolation review.
- [ ] Concurrent server-load and HTTP-streaming validation if required for release.
- [ ] Upstream patch compatibility review and actual GitHub PR.

## 15. Suggested pull-request description

### Title

Optimize AVX2/FMA matvec reduction while preserving runtime dispatch

### Summary

Replace scalar lane accumulation in the existing four-row/two-accumulator AVX2/FMA matrix-vector kernel with a vector reduction. The change is confined to `src/cpu.rs` and leaves runtime dispatch, fallback kernels, model files, dependencies and public interfaces unchanged relative to the measured platform-aware baseline.

### Performance

On an Intel Core Ultra 7 165U running Windows 11 with PiVo-1.4M, two per-case benchmark sessions reported 8.17% and 7.33% lower median matched-block RTF ratios. The second session reported 3.76% lower TTFA, 5.91% lower frame-p95 and 6.05% lower frame-p99 ratios. All blocks were retained, including unstable blocks. These are descriptive results for the tested environment, not universal speed guarantees or final-server throughput claims.

### Validation

The integrated application passed library/frontend tests, 18 independent-reference cases, CLI buffered/streamed comparisons, longer and multi-clause smoke cases, a portable-override smoke test, and loopback HTTP checks. The second per-case session passed all 384 saved-output checks with maximum candidate/baseline absolute sample difference approximately 0.0002020. Floating-point outputs are not bit-identical because reduction order changes.

### Limitations

Timing variation remains substantial. Older CPUs, AArch64, minimum Rust, disassembly, perceptual listening and near-limit recurrence are not certified by this change. The patch assumes the measured platform-aware baseline is already present or separately reviewed.

## 16. Evidence inventory and audit notes

This report uses the supplied benchmark summaries, profiling results and execution statuses from the experiment, plus the retrieved contents of `integration-results-upload.zip`.

Retain these artifacts privately or publish sanitized copies as appropriate:

| Evidence | What it establishes |
|---|---|
| `case-blocks-01/summary.json` | First per-case all-block ratios and controls |
| `case-blocks-02/summary.json` | Second per-case all-block ratios and controls |
| `case-blocks-02/blocks.json` | Instability flags and block-level results |
| `case-blocks-02/numerical-checks.json` | 384 saved-output checks |
| `case-blocks-*/batches.jsonl` | Raw request/frame observations |
| `reference-check-01/status.json` and logs | Initial independent reference validation |
| `integration-01/integration-status.json` | Integration state, commits, hashes and executed steps |
| `integration-01/application-audio-checks.json` | CLI numerical and stream/buffer checks |
| `integration-01/logs/*integrated-reference.log` | Three passing numerical tests per integrated reference case |
| `integration-01/logs/git-candidate-commit.log` | One-file, 19-insertion/24-deletion integration commit |
| `integration-01/r4a2-vector.patch` | Exact final source patch |
| `integration-01/source-provenance.json` | Baseline/candidate source hashes |

No synthetic performance data is used in the reported measurements. Helper self-tests that used mock audio/builds/HTTP are authoring checks only, not evidence that the application passed. The actual application results above come from the laptop execution logs.

### Documentation choices

This report separates production code from experiment tooling, distinguishes measured results from mechanism hypotheses, keeps regressions/noise visible, and provides exact local provenance without exposing private tenant URLs or personal machine identifiers. This makes the report suitable for a GitHub review without overstating performance or release readiness.
