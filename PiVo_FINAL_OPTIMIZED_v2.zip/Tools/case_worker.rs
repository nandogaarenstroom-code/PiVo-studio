//! Benchmark harness only: identical in both source trees, kernels untouched.
use pivo_runner::{Engine,SynthOptions};
use serde::Deserialize;
use serde_json::json;
use std::{env,fs,io::{self,BufRead,Write},path::PathBuf,time::Instant};
#[derive(Deserialize)]
struct Request { id:u64, text:String, voice:String, speed:f32, repeats:usize, warmups:usize }
fn measure(engine:&Engine,req:Request,out:&PathBuf)->Result<serde_json::Value,Box<dyn std::error::Error>> {
 if req.repeats==0 || req.repeats>50 || req.warmups>10 || req.text.len()>100000 || !req.speed.is_finite() || !(0.5..=2.0).contains(&req.speed) {return Err("invalid request".into());}
 let opts=SynthOptions{voice:req.voice,speed:req.speed,strict:true,overrides:Default::default()};
 for _ in 0..req.warmups {let _=engine.synthesize(&req.text,&opts)?;}
 let mut rows=Vec::new();let mut first_pcm=Vec::new();let mut expected=None;
 for rep in 0..req.repeats {
  let start=Instant::now();let mut stream=engine.synthesize_stream(&req.text,&opts)?;
  let mut pcm=Vec::new();let mut frame_ms=Vec::new();let mut first=None;
  loop {
   let ft=Instant::now();let next=stream.next_frame()?;let elapsed=ft.elapsed().as_secs_f64()*1000.0;
   match next {Some(frame)=>{
    if first.is_none(){first=Some(start.elapsed().as_secs_f64()*1000.0);}
    frame_ms.push(elapsed);pcm.extend_from_slice(&frame);
   },None=>break}
  }
  let total_ms=start.elapsed().as_secs_f64()*1000.0;
  // Validation and serialization are outside the synthesis timer.
  if pcm.is_empty() || !pcm.iter().all(|x|x.is_finite()){return Err("empty/nonfinite output".into());}
  if let Some(n)=expected {if n!=pcm.len(){return Err("sample count changed across repetitions".into());}}
  expected=Some(pcm.len());
  let seconds=pcm.len() as f64/engine.sample_rate() as f64;
  rows.push(json!({"repeat":rep,"samples":pcm.len(),"sample_rate":engine.sample_rate(),"frames":frame_ms.len(),
   "total_ms":total_ms,"ttfa_ms":first,"rtf":total_ms/1000.0/seconds,"frame_ms":frame_ms}));
  if rep==0 {first_pcm=pcm;}
 }
 let name=format!("sample-{}.f32",req.id);
 let bytes:Vec<u8>=first_pcm.iter().flat_map(|x|x.to_le_bytes()).collect();fs::write(out.join(&name),bytes)?;
 Ok(json!({"id":req.id,"rows":rows,"pcm":name}))
}
fn main()->Result<(),Box<dyn std::error::Error>> {
 let args:Vec<String>=env::args().collect();if args.len()!=3{return Err("usage: case_worker MODEL PCM_OUT".into());}
 let out=PathBuf::from(&args[2]);fs::create_dir_all(&out)?;
 let engine=Engine::load(&args[1])?;let backend=pivo_runner::cpu::backend_name();
 if backend!="avx2_fma" {return Err(format!("expected avx2_fma, got {backend}").into());}
 let mut stdout=io::BufWriter::new(io::stdout().lock());
 writeln!(stdout,"{}",json!({"ready":true,"backend":backend}))?;stdout.flush()?;
 for line in io::stdin().lock().lines() {
  let line=line?;if line.trim()=="quit"{break;}
  let result=serde_json::from_str::<Request>(&line).map_err(|e|e.to_string())
   .and_then(|req|measure(&engine,req,&out).map_err(|e|e.to_string()));
  let value=match result {Ok(v)=>v,Err(e)=>json!({"error":e})};
  writeln!(stdout,"{}",value)?;stdout.flush()?;
 }
 Ok(())
}
