# PiVo Studio CPU optimization: checklist and agent prompt (revised)

Revision notes: kernel speedups use the calibrated benchmark run. Measured numbers are reference targets, not claims to copy. The prompt now starts from the exact patch instead of describing the code in prose.

## Reference results (Intel Core Ultra 7 165U, Windows 11, PiVo-1.4M, AVX2/FMA backend)

Isolated matvec kernel, original versus optimized public dispatch, median of 7 rounds with calibrated timing windows:

| Shape (rows x width) | Original | Optimized | Speedup |
|---|---:|---:|---:|
| 96 x 96 | 5,384 ns | 1,108 ns | 4.86x |
| 128 x 128 | 6,945 ns | 1,314 ns | 5.29x |
| 160 x 160 | 12,435 ns | 2,169 ns | 5.73x |
| 384 x 512 | 87,695 ns | 11,082 ns | 7.91x |

An earlier, less carefully timed run gave 5.26x to 7.03x on the same shapes. Quote the calibrated range, roughly 4.9x to 7.9x. These are isolated kernels on one laptop, not application speedups.

Application level, `r4a2_vector` versus the already SIMD-optimized baseline (two per-case sessions, 24 cases, ABBA/BAAB blocks, identical-baseline controls, all blocks retained):

| Metric (median matched-block ratio change) | Session 1 | Session 2 |
|---|---:|---:|
| RTF | -8.17% | -7.33% |
| TTFA | -4.16% | -3.76% |
| Frame p95 | -8.76% | -5.91% |
| Frame p99 | -6.02% | -6.05% |
| RTF wins | 38/48 | 37/48 |

Limits: most blocks were flagged for instability; the worst session-2 candidate block was 17.17% slower; the identical-baseline control moved 0.7% to 2.5% in median RTF. Do not multiply kernel and application figures. Do not claim a 7x application speedup.

Correctness evidence: 384/384 saved-output checks passed in session 2 (max abs difference 0.000202); 18/18 independent reference cases passed on the integrated build; CLI, streaming, longer-text, multi-clause, portable-override and loopback HTTP smoke tests passed.

Rejected after measurement (do not include): shape-aware narrow-width dispatcher (slower in the application); memory/copy changes in `src/model.rs` (RTF +0.48%, frame p95 +1.12%, 23/48 wins, control +2.48%); `r2a2`, `r4a1`, `r8a1`, `r4a2_unroll2`.

## Checklist

### 1. Inputs
- [ ] Original source tree (the pre-optimization PiVo Studio snapshot).
- [ ] `all-cpu-improvements.patch` (original to final; touches Cargo.toml, src/cpu.rs, src/lib.rs, src/model.rs, tests/cpu_dispatch.rs, tests/numerics.rs).
- [ ] `r4a2-vector.patch` (the final one-function refinement only).
- [ ] Model `PiVo-1.4M` (Hugging Face `empero-ai/PiVo-1.4M`).
- [ ] Rust 1.89 or newer. Tested on 1.99.1. The 1.89 floor comes from the AVX-512 intrinsics and was never executed.
- [ ] For reference tests: Python with `numpy`, `onnxruntime`, and the model's own `pivo` Python modules.

### 2. Apply, do not reimplement
- [ ] `git apply --check all-cpu-improvements.patch` on a clean copy of the original, then apply.
- [ ] If it does not apply, stop and report. Never recreate the kernels from prose.
- [ ] Final tree must differ from the original only in the six files above.

### 3. Build and test
- [ ] `cargo test --locked --release --lib --bins --test frontend`
- [ ] `cargo build --locked --release --bin pivo-studio`
- [ ] 18 reference cases (3 texts x 2 voices x 3 speeds): `cargo test --locked --release --test numerics -- --nocapture` with `PIVO_MODEL_DIR`, `PIVO_REF_DIR`, `PIVO_REQUIRE_REFERENCE=1`; no skipped tests, tolerances unchanged.
- [ ] CLI help and voices; buffered WAV and streamed f32; both voices at 0.5, 1.0, 2.0; one longer single clause; one multi-clause input.
- [ ] `PIVO_CPU_BACKEND=portable` smoke run.
- [ ] Loopback HTTP: `/health`, `/v1/voices`, WAV synthesis.

### 4. Cross-target checks (compile only)
- [ ] `rustup target add aarch64-unknown-linux-gnu` then `cargo check --lib --target aarch64-unknown-linux-gnu` to compile the NEON path.
- [ ] Treat NEON and AVX-512 as compiled but unexecuted unless native hardware is available.

### 5. Benchmark
- [ ] Benchmark baseline = original + cumulative patch with `r4a2-vector.patch` reverse-applied (`git apply -R --check` first). Candidate = the full cumulative patch.
- [ ] 24 cases, 2 cycles, ABBA/BAAB per case, second identical-baseline control worker, 5 repeats, 2 warmups, all blocks retained.
- [ ] Report matched-block median ratios for RTF, TTFA, frame p95, frame p99, plus control contrast and instability flags.

### 6. Deliverables
- [ ] Updated source, cumulative patch, incremental patch, changed-file summary, release executable, rollback executable, test and benchmark reports, PR text, open release gates.

### 7. Open release gates (not done)
- [ ] Native AArch64 and other OS runs; older or restricted CPU runs; minimum-Rust build; assembly review; near-limit recurrence; listening review.

---

# Agent prompt

```text
You are a Rust engineer. Reproduce a validated CPU optimization of PiVo Studio (local streaming text-to-speech) by applying a supplied patch to the original source, then verifying it.

INPUTS (all provided with this prompt)
1. original/ : the original PiVo Studio source tree.
2. all-cpu-improvements.patch : exact original-to-final change (Cargo.toml, src/cpu.rs, src/lib.rs, src/model.rs, tests/cpu_dispatch.rs, tests/numerics.rs).
3. r4a2-vector.patch : the final refinement alone, a rewrite of the reduction in avx2_fma::matvec_into.
4. The PiVo-1.4M model and its Python reference modules.

DEFINITIONS
- "SIMD baseline": original + all-cpu-improvements.patch with r4a2-vector.patch reverse-applied.
- "Final": original + all-cpu-improvements.patch.
- r4a2_vector: four output rows per block, two 256-bit accumulators per row, with the accumulators combined by a vector reduction instead of a scalar lane loop.

RULES
- Apply the patch. Do not rewrite or "improve" the kernels. If git apply --check fails, stop and report the failure.
- The final tree may differ from the original only in the six files listed.
- Do not change public APIs, CLI or HTTP behavior, model files, numerical tolerances, the release profile, or the 3,000-frame input limit.
- Do not add threading, quantization, weight packing, operation fusion, new dispatch rules, or automatic AVX-512 selection.
- Do not include these rejected experiments: shape-aware narrow-width dispatch; scratch-buffer and copy reductions in src/model.rs; kernel variants r2a2, r4a1, r8a1, r4a2_unroll2.

STEPS
1. Apply the cumulative patch to a clean copy of original/ and confirm only the six files changed.
2. Use Rust 1.89 or newer and a locked release build.
3. Run: cargo test --locked --release --lib --bins --test frontend
4. Build: cargo build --locked --release --bin pivo-studio
5. Run the 18-case reference matrix (3 texts x 2 voices x 3 speeds) with PIVO_REQUIRE_REFERENCE=1. Missing reference files must fail, not skip. Do not loosen tolerances.
6. Smoke test: CLI voices; buffered WAV and streamed f32 for both voices at speeds 0.5, 1.0, 2.0; one longer single clause; one multi-clause input; PIVO_CPU_BACKEND=portable; loopback HTTP /health, /v1/voices and WAV synthesis.
7. Run cargo check --lib for aarch64-unknown-linux-gnu to compile the NEON path. Report NEON and AVX-512 as compiled but not executed unless you ran them on native hardware.
8. Benchmark SIMD baseline versus Final on the same machine: 24 cases, 2 cycles, ABBA/BAAB per case, a second identical-baseline control worker, 5 repeats, 2 warmups, all blocks retained. Report matched-block median ratios for RTF, TTFA, frame p95 and frame p99, with control contrast and instability flags.

REFERENCE TARGETS (from one laptop; report your own measurements and do not copy these)
- Isolated matvec kernels versus the original: about 4.9x to 7.9x on the 96x96 to 384x512 shapes.
- Final versus SIMD baseline, application level: median RTF ratio about 7% to 8% lower, with TTFA, frame p95 and frame p99 lower by roughly 4% to 9%.
- Final versus SIMD baseline numerical difference: maximum absolute sample difference about 0.0002. Output is not bit-identical because the reduction order changed.

CLAIMS TO AVOID
No 7x application speedup; no universal or all-CPU speedup; no bit-identical output; no zero regressions; no ARM or older-CPU certification; no confidence interval. Do not multiply kernel and application figures.

DELIVERABLES
Updated source; the two patches; changed-file summary; release executable; test and reference results; benchmark results with variability and any regressions stated; rollback instructions; a concise pull-request description; the list of release gates still open (native AArch64, older CPUs, minimum-Rust build, assembly review, near-limit sequences, listening review).
```
