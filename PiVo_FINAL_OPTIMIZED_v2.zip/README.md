﻿# PiVo final optimized package

Accepted production candidate:

- Branch: integration/r4a2-vector
- Commit: 416d2a734cf8776a3d5503bc620a8c8d1afca5e8
- Optimization: platform-aware SIMD plus r4a2_vector
- Memory/copy experiment: excluded because no overall speedup was measured

## Contents

- Source: accepted optimized source archive
- Binaries: optimized application
- Rollback: validated pre-r4a2 application
- Patches: exact accepted incremental patch
- Documentation: implementation and performance reports
- Evidence: benchmark, numerical, provenance, and reference summaries
- Tools: selected reproducibility scripts

## Measured performance

Selected matvec kernels:
- about 4.9x to 7.9x faster than original implementations (calibrated run; earlier run gave 5.26x to 7.03x)

r4a2_vector versus the SIMD baseline:
- 8.17% lower median matched-block RTF ratio in session 1
- 7.33% lower median matched-block RTF ratio in session 2

These are separate comparisons. There is no claim of a 7x application speedup.

See CORRECTIONS.md for changes since the first package.
