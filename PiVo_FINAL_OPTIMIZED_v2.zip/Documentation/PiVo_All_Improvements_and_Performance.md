> **Superseded in part.** The kernel speedup figures here (5.26x to 7.03x) come from an early, less carefully timed run. The calibrated run gives about 4.9x to 7.9x. See PiVo_Implementation_Checklist_and_Prompt.md and CORRECTIONS.md.

# Cumulative PiVo CPU improvements: original source to validated integrated candidate

## Scope

This document covers BOTH the initial platform-aware/SIMD work and the final
`r4a2_vector` refinement. The cumulative patch must be generated from the exact
recorded original snapshot to the validated integration source. The previously
shown 19-insertion/24-deletion patch contains ONLY the final refinement.

The original and final full CPU source snapshots are currently on the user's
laptop. The accompanying exporter reads those exact snapshots, verifies hashes,
creates a cumulative Git patch, and proves it reconstructs the selected integrated
files byte-for-byte. It does not regenerate kernels from descriptions.

## Initial platform-aware changes retained in the final application

- A dedicated CPU-kernel module, wired into the library and model implementation.
- Centralized primitive dispatch rather than leaving the primitive implementations
  embedded solely in the model source.
- A portable fallback preserving the original primitive formulas.
- Runtime feature-checked implementation tables, selected once with OnceLock.
- x86 implementations for SSE2, AVX, AVX/FMA, AVX2/FMA and opt-in AVX-512.
- AArch64 NEON implementation and portable fallback for other targets.
- Explicit vector implementations for dot products, matrix-vector products and
  RMSNorm reductions; not every operation is hand-vectorized.
- Four-output-row blocked matrix-vector loops with multiple vector accumulators,
  unaligned loads, vector remainders and scalar tails.
- Safe public dimension checks around dispatched dot/matrix-vector operations,
  including checked matrix-size multiplication.
- Backend override through PIVO_CPU_BACKEND and selected-backend reporting.
- Automatic selection favors supported AVX2/FMA, AVX/FMA, AVX, SSE2 or NEON paths;
  AVX-512 is not automatically preferred.
- Existing public small-width portable behavior retained. The rejected shape-aware
  dispatcher is NOT part of the validated final application.
- Any recorded Cargo manifest changes are exported rather than guessed. Minimum-
  toolchain execution remains a release gate, not a verified compatibility claim.

Primitive tables cover dot, matvec, RMSNorm, RoPE, convolutions, SiLU, softmax and
clipping. Some are target-feature copies of scalar source rather than rewritten
SIMD algorithms. Do not advertise every table entry as an independently optimized
vector kernel or claim vector transcendental math was added.

## Final refinement retained

Inside avx2_fma::matvec_into:

1. Add the two 256-bit accumulators lane by lane.
2. Combine their upper/lower 128-bit halves.
3. Use horizontal additions to obtain the scalar result.
4. Retain the existing scalar input tail and output-row remainder handling.

This replaces temporary-lane-array stores and serial scalar lane accumulation at
the source level. The compiler's actual instruction savings still require assembly
review. Four-row blocking and two accumulators already existed in the SIMD baseline.

The final refinement changes floating-point reduction order. Audio is not bit-identical.

## Supporting validation changes

The recorded integrated snapshot also contains parameterized numerical tests for
text, voice and speed using shared case manifests. The exporter includes recorded
src/ and tests/ changes plus Cargo manifests/lockfile changes, if present. It excludes
experimental examples, benchmark output, PCM, model weights, private logs and failed
candidate variants. Keep test infrastructure reviewable separately from production
code when submitting upstream.

## Measured performance: two different baselines

### Initial SIMD work versus original scalar implementation

Selected matrix-vector kernel medians from the early shape benchmark:

| Rows x width | Original | Initial SIMD public dispatch | Speedup |
|---|---:|---:|---:|
| 96 x 96 | 2,480.952 ns | 471.429 ns | 5.26x |
| 128 x 128 | 4,355 ns | 815 ns | 5.34x |
| 160 x 160 | 6,795 ns | 1,160 ns | 5.86x |
| 384 x 512 | 49,070 ns | 6,980 ns | 7.03x |

These are selected isolated kernel results, NOT whole-application speedups, and NOT
new measurements of the final vector-reduction candidate. The original microbenchmark
used short timing windows and had outliers; do not present it as release-grade
statistical certification or universal hardware behavior.

### Final reduction versus already SIMD-optimized baseline

All-block per-case application results on Core Ultra 7 165U, Windows 11, PiVo-1.4M:

| Metric | Session 1 | Session 2 |
|---|---:|---:|
| Median matched-block RTF ratio change | -8.17% | -7.33% |
| Median TTFA ratio change | -4.16% | -3.76% |
| Median frame-p95 ratio change | -8.76% | -5.91% |
| Median frame-p99 ratio change | -6.02% | -6.05% |
| RTF wins | 38/48 | 37/48 |

Each session used 24 cases, ABBA/BAAB candidate blocks, repeated-baseline controls,
two cycles, and 1,920 measured requests including controls. All flagged observations
remain in the primary result. These are medians of block ratios, not pooled request
percentiles, formal confidence intervals, or total-wall-time ratios.

Substantial variability remained: 95/96 and 89/96 total blocks were flagged. Session
2 had 16 control-contrast flags; its worst candidate RTF block was 17.17% slower.
The near-zero median baseline-control contrast does not prove low variance.

Do NOT multiply the 7.03x kernel speedup by the later application-level improvement.
A single cumulative original-to-final application speedup is not established by these
two different comparisons. The final integrated CLI/server smoke run was functional
validation, not a new performance benchmark.

## Validation completed on the tested laptop

- Initial/candidate kernel compilation and correctness tests.
- Second per-case session: 384 saved-output checks, zero failures, maximum absolute
  candidate/baseline sample difference 0.00020200340077280998.
- Integrated independent reference matrix: 18 cases, three numerical tests per case,
  no skipped tests; existing tolerances unchanged.
- Actual baseline/candidate application builds, library and frontend tests.
- Real CLI buffered/streamed output checks, both voices and three speeds.
- Longer single-clause and twelve-clause document smoke cases.
- Portable override smoke on the AVX2-capable machine, not old-CPU proof.
- Loopback HTTP health, voice-list and WAV synthesis checks for both builds.
- Clean integration repository, baseline executable retained for rollback.

## Provenance

- Baseline local commit: fe8267c431c2ef135d0a640a1a2405a150f413f6
- Integrated local commit: 416d2a734cf8776a3d5503bc620a8c8d1afca5e8
- Final CPU SHA-256: f04364a897b35fa971e745f06e81aa5a4d7c29184bf666f087aa461b5a0baf74
- Build flags: -C target-cpu=x86-64; locked release profile.

The local baseline commit is the already optimized baseline, not the original
upstream scalar snapshot. A Git diff of those two local commits alone omits the
initial SIMD work. Use the cumulative exporter for original-to-final changes.

## Export the complete patch

Place export_all_improvements.py in the existing PiVo_targeted_kernel_suite folder:

```powershell
.\.venv-validation\Scripts\python.exe .\export_all_improvements.py --previous ".\results-kernel-02" --integration ".\integration-01" --out ".\all-improvements-01"
```

The exporter uses results-kernel-02/source-original, or the suite's original folder.
An explicit --original path is available if necessary. Original hashes must match.

Generated outputs:

- all-cpu-improvements.patch: cumulative exact Git patch.
- ALL_CHANGES.md: the complete cumulative diff in a Markdown diff fence.
- updated-files/: final versions of changed source/test/build files.
- original-files/: corresponding original files, where present.
- diff-stat.txt: exact changed-file statistics.
- export-status.json: source/patch hashes and round-trip check.
- all-cpu-improvements.zip: packaged output.

No benchmark rerun, source mutation, remote push, or upstream patch application occurs.
The exporter checks patch application against a temporary copy of the original and
compares the resulting files byte-for-byte with the integrated source. It does not
prove applicability to an arbitrary current GitHub checkout.

## Concise cumulative PR description

### Title
Add runtime-dispatched CPU kernels and optimize AVX2/FMA matvec reduction

### Summary
- Introduce platform-aware CPU primitive dispatch with portable fallback and
  feature-checked x86/AArch64 implementations.
- Add SIMD dot/matvec/RMSNorm reductions and blocked matrix-vector processing.
- Include the validated AVX2/FMA vector-reduction refinement.
- Preserve model weights, public application interfaces and scalar-tail handling.
- Include recorded reference-test improvements without experimental dispatch policies.

### Performance
Selected initial matrix-vector kernels measured 5.26-7.03x faster than their original
implementations. Separately, the final reduction refinement lowered median matched-
block application RTF ratios by 8.17% and 7.33% versus the already optimized baseline
in two Windows/Core Ultra 7 165U sessions. All blocks were retained; variability and
individual regressions remain. These results do not establish a 7x application speedup.

### Validation and limitations
Integrated builds, numerical references, CLI buffered/streamed checks and loopback
HTTP smoke tests passed on the tested laptop/model. Floating-point output is not
bit-identical. AArch64/other platforms, older CPUs, minimum Rust, disassembly,
listening and near-limit recurrence remain release gates. No production deployment.

## Documentation approach

The report separates initial SIMD gains from the incremental reduction gain, keeps
failed experiments out of the final patch, and states unresolved release checks.
The actual cumulative diff is exported from verified source, not reconstructed from
this narrative. Private paths/tenant URLs and raw model/audio artifacts should not
be committed to a public project.
