#!/usr/bin/env python3
"""Resume PiVo validation using existing builds; no kernel edits or adoption."""
import argparse, array, hashlib, importlib, json, math, os, statistics, subprocess, sys, time, zipfile
from pathlib import Path

def main():
 p=argparse.ArgumentParser()
 p.add_argument('mode',choices=['preflight','reference','confirm'])
 p.add_argument('--previous',type=Path,default=Path('results-kernel-02'))
 p.add_argument('--model',type=Path,default=Path('C:/PiVoTest/models/PiVo-1.4M'))
 p.add_argument('--out',type=Path)
 a=p.parse_args();root=Path(__file__).resolve().parent;prev=a.previous.resolve();model=a.model.resolve()
 if a.mode=='preflight':
  sys.path.insert(0,str(model));bad=[]
  for name in ['numpy','onnxruntime','pivo.text','pivo.phase','pivo.audio']:
   try:importlib.import_module(name);print('OK:',name)
   except Exception as e:bad.append(name);print('BLOCKED:',name,type(e).__name__,str(e))
  return 1 if bad else 0
 if not a.out:p.error('--out is required for reference/confirm')
 out=a.out.resolve()
 if out.exists() and any(out.iterdir()):p.error('Use a new output folder; previous results are never overwritten')
 out.mkdir(parents=True,exist_ok=True)
 state={'mode':a.mode,'status':'started','adopted':False,'executed':[],'failures':[],
 'limitations':['No automatic adoption','Existing short workload only','No CPU affinity or power-setting changes','No independent verification of historical binary provenance']}
 def save():(out/'status.json').write_text(json.dumps(state,indent=2))
 def run(cmd,log,env,cwd=None):
  print('Running:',log,flush=True)
  with (out/log).open('w') as f:rc=subprocess.run(list(map(str,cmd)),stdout=f,stderr=subprocess.STDOUT,env=env,cwd=cwd).returncode
  state['executed'].append({'command':list(map(str,cmd)),'returncode':rc,'log':log});save()
  if rc:raise RuntimeError('Inspect '+log)
 def clean_env():
  env=os.environ.copy()
  for key in list(env):
   if key.startswith(('CARGO_TARGET_','CARGO_PROFILE_')) or key in ['RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','PIVO_CPU_BACKEND','PIVO_EXPECT_CPU_BACKEND']:
    env.pop(key,None)
  env.update({'RUSTFLAGS':'-C target-cpu=x86-64','CARGO_INCREMENTAL':'0','PIVO_CPU_BACKEND':'avx2_fma','PIVO_EXPECT_CPU_BACKEND':'avx2_fma'})
  return env
 try:
  prior=json.loads((prev/'status.json').read_text())
  if prior.get('source_integrity')!='passed':raise ValueError('Previous source integrity did not pass')
  hashes=json.loads((prev/'source-hashes.json').read_text())
  for label in ['baseline','r4a2_vector']:
   for f in (prev/('source-'+label)).rglob('*'):
    if f.is_file():
     key=label+'/'+f.relative_to(prev/('source-'+label)).as_posix()
     if key in hashes and hashlib.sha256(f.read_bytes()).hexdigest()!=hashes[key]:raise ValueError('Source changed: '+key)
  sample=json.loads((prev/'app-0-baseline/measurements.json').read_text())
  cases={row['case']:row for row in sample['rows']}
  if a.mode=='reference':
   state['limitations'].append('Independent reference generator excludes multi-clause t3 cases and retains model-specific assumptions')
   for case,row in cases.items():
    if case.startswith('t3_'):continue
    ref=out/case;ref.mkdir()
    run([sys.executable,root/'generate_reference.py','--model-dir',model,'--out',ref,'--text',row['text'],'--voice',row['voice'],'--speed',row['speed']],case+'-generate.log',clean_env())
    for label in ['baseline','r4a2_vector']:
     env=clean_env();env.update({'CARGO_TARGET_DIR':str(prev/('target-'+label)),'PIVO_MODEL_DIR':str(model),'PIVO_REF_DIR':str(ref),'PIVO_REQUIRE_REFERENCE':'1'})
     run(['cargo','test','--locked','--release','--test','numerics','--','--nocapture'],case+'-'+label+'.log',env,prev/('source-'+label))
   state['status']='reference_checks_passed'
  else:
   # ABBA then BAAB. Same binary controls, equal order exposure; no new compilation.
   order=['baseline','r4a2_vector','r4a2_vector','baseline','r4a2_vector','baseline','baseline','r4a2_vector']
   state['limitations'].append('Interleaving is per whole-workload process, not per utterance; scheduling/thermal variation can remain')
   state['binary_sha256']={}
   for label in set(order):
    exe=prev/('target-'+label)/'release/examples'/('validation_probe.exe' if os.name=='nt' else 'validation_probe')
    state['binary_sha256'][label]=hashlib.sha256(exe.read_bytes()).hexdigest()
   records=[]
   for index,label in enumerate(order):
    exe=prev/('target-'+label)/'release/examples'/('validation_probe.exe' if os.name=='nt' else 'validation_probe')
    dest=out/('run-'+str(index)+'-'+label)
    run([exe,model,dest,10,2],'run-'+str(index)+'-'+label+'.log',clean_env())
    data=json.loads((dest/'measurements.json').read_text())
    if data['backend']!='avx2_fma':raise ValueError('Unexpected backend')
    if len(data['rows'])!=len(cases)*10:raise ValueError('Incomplete workload')
    for case in cases:
     rows=[r for r in data['rows'] if r['case']==case]
     if len(rows)!=10 or {r['samples'] for r in rows}!={cases[case]['samples']}:raise ValueError('Repetition/output length mismatch')
    records.append({'index':index,'variant':label,'data':data,'directory':str(dest)})
    time.sleep(5)
   # Compare every saved output to the first baseline run; never silently accept mismatches.
   ref=Path(records[0]['directory']);numerics=[]
   def audio(path):
    b=path.read_bytes()
    if len(b)%4:raise ValueError('Malformed PCM')
    x=array.array('f');x.frombytes(b)
    if sys.byteorder!='little':x.byteswap()
    if not x or not all(math.isfinite(v) for v in x):raise ValueError('Invalid PCM')
    return x
   for rec in records:
    for case in cases:
     x=audio(ref/(case+'.f32'));y=audio(Path(rec['directory'])/(case+'.f32'))
     if len(x)!=len(y):raise ValueError('PCM length mismatch')
     delta=max(abs(u-v) for u,v in zip(x,y));passed=delta==0 if rec['variant']=='baseline' else delta<0.02
     numerics.append({'run':rec['index'],'variant':rec['variant'],'case':case,'max_abs':delta,'pass':passed})
   (out/'numerical-checks.json').write_text(json.dumps(numerics,indent=2))
   # Preserve raw requests/frame timings for independent analysis, no premature adoption score.
   (out/'confirmation-raw.json').write_text(json.dumps(records,indent=2))
   if not all(x['pass'] for x in numerics):raise ValueError('Numerical mismatch; inspect numerical-checks.json')
   state['status']='confirmation_collected';state['notes']='Analyze adjacent pairs, baseline drift and per-case regressions before adoption'
 except Exception as e:state['status']='failed';state['failures'].append(str(e))
 finally:
  save()
  with zipfile.ZipFile(out/'upload.zip','w',zipfile.ZIP_DEFLATED) as z:
   for f in out.iterdir():
    if f.is_file() and f.suffix in ['.json','.log']:z.write(f,f.name)
  print(json.dumps(state,indent=2));print('Upload:',out/'upload.zip')
 return 1 if state['failures'] else 0
if __name__=='__main__':sys.exit(main())
