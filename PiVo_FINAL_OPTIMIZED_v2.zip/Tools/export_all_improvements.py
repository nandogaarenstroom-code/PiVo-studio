#!/usr/bin/env python3
"""Export the cumulative original-to-final patch for the PiVo CPU work.

Read-only for your existing folders. Needs git and Python 3 only.
Compares the original snapshot with the COMMITTED integration branch, limited to
src/, tests/, Cargo.toml and Cargo.lock, then proves the patch rebuilds the final files.
"""
import argparse, hashlib, io, json, os, shutil, subprocess, sys, tempfile, zipfile
from pathlib import Path

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def wanted(rel):
    return rel in ("Cargo.toml", "Cargo.lock") or rel.startswith(("src/", "tests/"))
def files_under(root):
    return {p.relative_to(root).as_posix(): p for p in root.rglob("*")
            if p.is_file() and wanted(p.relative_to(root).as_posix())}

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--suite", type=Path, default=Path("."), help="folder holding results-kernel-02 and integration-01")
    ap.add_argument("--original", type=Path, help="override original snapshot (default: results-kernel-02/source-original)")
    ap.add_argument("--branch", default="integration/r4a2-vector")
    ap.add_argument("--expect-commit", default="416d2a734cf8776a3d5503bc620a8c8d1afca5e8")
    ap.add_argument("--out", type=Path, required=True)
    a = ap.parse_args()
    suite, out = a.suite.resolve(), a.out.resolve()
    original = (a.original or suite / "results-kernel-02" / "source-original").resolve()
    repo = suite / "integration-01" / "repo"
    if out.exists() and any(out.iterdir()): ap.error("--out must be new or empty")
    if suite in out.parents and out.parent == suite: pass
    for p in (original, repo):
        if not p.is_dir(): sys.exit(f"Missing folder: {p}")
    if not shutil.which("git"): sys.exit("git not found")
    env = {k: v for k, v in os.environ.items() if not k.startswith("GIT_")}
    def git(args, cwd, **kw):
        return subprocess.run(["git", "-c", "core.autocrlf=false", "-c", "core.safecrlf=false",
                               "-c", "commit.gpgsign=false", "-c", "user.name=export",
                               "-c", "user.email=export@localhost", *args],
                              cwd=cwd, env=env, check=True, capture_output=True, **kw)
    head = git(["rev-parse", a.branch], repo).stdout.decode().strip()
    if a.expect_commit and head != a.expect_commit:
        sys.exit(f"Branch {a.branch} is {head}, expected {a.expect_commit}")
    dirty = git(["status", "--porcelain", "--untracked-files=no"], repo).stdout.decode().strip()
    if dirty: sys.exit("Tracked changes in integration repo; commit or revert them first:\n" + dirty)

    # Verify the original snapshot against the recorded manifest when available.
    manifest = suite / "results-kernel-02" / "source-hashes.json"
    verified = 0
    if manifest.is_file():
        for key, h in json.loads(manifest.read_text()).items():
            key = key.replace("\\", "/")
            if key.startswith("original/"):
                f = original / key[len("original/"):]
                if not f.is_file() or sha(f) != h: sys.exit(f"Original snapshot mismatch: {key}")
                verified += 1
    out.mkdir(parents=True, exist_ok=True)

    with tempfile.TemporaryDirectory() as td:
        td = Path(td); final = td / "final"; work = td / "work"; final.mkdir(); work.mkdir()
        data = git(["archive", "--format=zip", a.branch], repo).stdout
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            for n in z.namelist():
                if n.endswith("/"): continue
                if Path(n).is_absolute() or ".." in Path(n).parts: sys.exit("Unsafe path in archive")
                (final / n).parent.mkdir(parents=True, exist_ok=True)
                (final / n).write_bytes(z.read(n))
        before, after = files_under(original), files_under(final)
        changed = sorted(r for r in set(before) | set(after)
                         if (r in before) != (r in after) or
                         (r in before and before[r].read_bytes() != after[r].read_bytes()))
        if not changed: sys.exit("No differences found; wrong source folders?")
        for r, p in before.items():
            (work / r).parent.mkdir(parents=True, exist_ok=True); shutil.copy2(p, work / r)
        git(["init"], work); git(["add", "--force", "--all"], work); git(["commit", "-m", "original"], work)
        for r in changed:
            if r in after:
                (work / r).parent.mkdir(parents=True, exist_ok=True); shutil.copy2(after[r], work / r)
            elif (work / r).exists(): (work / r).unlink()
        git(["add", "--force", "--all"], work)
        patch = git(["diff", "--cached", "--binary", "HEAD"], work).stdout
        stat = git(["diff", "--cached", "--stat", "HEAD"], work).stdout
        (out / "all-cpu-improvements.patch").write_bytes(patch)
        (out / "diff-stat.txt").write_bytes(stat)
        # Round trip: original + patch must equal the final files byte for byte.
        git(["reset", "--hard", "HEAD"], work); git(["clean", "-fd"], work)
        git(["apply", "--check", str(out / "all-cpu-improvements.patch")], work)
        git(["apply", str(out / "all-cpu-improvements.patch")], work)
        for r in changed:
            w = work / r
            if (r in after) != w.exists() or (w.exists() and w.read_bytes() != after[r].read_bytes()):
                sys.exit(f"Round-trip mismatch: {r}")
        for r in changed:
            for tree, name in ((original, "original-files"), (final, "updated-files")):
                s = tree / r
                if s.exists():
                    d = out / name / r; d.parent.mkdir(parents=True, exist_ok=True); shutil.copy2(s, d)
    text = patch.decode("utf-8", errors="replace")
    (out / "ALL_CHANGES.md").write_text("# Cumulative patch: original to integration/r4a2-vector\n\n```diff\n" + text + "\n```\n", encoding="utf-8")
    (out / "export-status.json").write_text(json.dumps({
        "status": "exported", "commit": head, "files_changed": changed,
        "original_files_hash_verified": verified, "patch_sha256": sha(out / "all-cpu-improvements.patch"),
        "round_trip": "passed: original + patch reproduces final files byte for byte",
        "scope": "src/, tests/, Cargo.toml, Cargo.lock only; examples and benchmark tools excluded"}, indent=2))
    print(stat.decode()); print("Files changed:", len(changed)); print("Output:", out)

if __name__ == "__main__": main()
