#!/usr/bin/env python3
r"""Add the cumulative patch and corrections to PiVo_FINAL_OPTIMIZED, then rebuild the manifest and zip.

Never modifies your existing folders in place except a NEW output copy.
  python assemble_final_package.py --final ..\PiVo_FINAL_OPTIMIZED --patch ..\all-improvements-01 --docs . --out ..\PiVo_FINAL_OPTIMIZED_v2
"""
import argparse, hashlib, json, shutil, sys, zipfile
from pathlib import Path

BANNER = ("> **Superseded in part.** The kernel speedup figures here (5.26x to 7.03x) come from an early, "
          "less carefully timed run. The calibrated run gives about 4.9x to 7.9x. See "
          "PiVo_Implementation_Checklist_and_Prompt.md and CORRECTIONS.md.\n\n")
OLD_README = "- 5.26x to 7.03x faster than original implementations"
NEW_README = "- about 4.9x to 7.9x faster than original implementations (calibrated run; earlier run gave 5.26x to 7.03x)"

def sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""): h.update(b)
    return h.hexdigest()

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--final", type=Path, required=True)
    ap.add_argument("--patch", type=Path, required=True, help="all-improvements-01 folder")
    ap.add_argument("--docs", type=Path, required=True, help="folder with the revised markdown and corrections")
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--strip-examples", action="store_true",
                    help="drop examples/ from the source zip (alters the tested source; off by default)")
    a = ap.parse_args()
    final, patchdir, docs, out = (p.resolve() for p in (a.final, a.patch, a.docs, a.out))
    if out.exists(): sys.exit(f"{out} already exists")
    st = json.loads((patchdir / "export-status.json").read_text())
    if st.get("status") != "exported" or not str(st.get("round_trip", "")).startswith("passed"):
        sys.exit("export-status.json does not show a passed export")
    for need in ("all-cpu-improvements.patch", "ALL_CHANGES.md", "diff-stat.txt"):
        if not (patchdir / need).is_file(): sys.exit(f"Missing {need} in {patchdir}")
    if sha(patchdir / "all-cpu-improvements.patch") != st["patch_sha256"]:
        sys.exit("Patch hash does not match export-status.json")
    for need in ("PiVo_Implementation_Checklist_and_Prompt.md", "CORRECTIONS.md"):
        if not (docs / need).is_file(): sys.exit(f"Missing {need} in {docs}")

    shutil.copytree(final, out)
    (out / "FINAL_MANIFEST.json").unlink(missing_ok=True)
    for d in ("Patches", "Evidence", "Documentation", "Tools"): (out / d).mkdir(exist_ok=True)
    shutil.copy2(patchdir / "all-cpu-improvements.patch", out / "Patches")
    shutil.copy2(patchdir / "ALL_CHANGES.md", out / "Patches")
    shutil.copy2(patchdir / "diff-stat.txt", out / "Evidence")
    shutil.copy2(patchdir / "export-status.json", out / "Evidence" / "cumulative-export-status.json")
    for name in ("PiVo_Implementation_Checklist_and_Prompt.md", "CORRECTIONS.md"):
        shutil.copy2(docs / name, out / "Documentation" / name)
    for name in ("export_all_improvements.py", "assemble_final_package.py"):
        for base in (docs, Path(__file__).resolve().parent, patchdir.parent):
            f = base / name
            if f.is_file(): shutil.copy2(f, out / "Tools" / name); break
    shutil.copy2(docs / "CORRECTIONS.md", out / "CORRECTIONS.md")

    banners = 0
    for name in ("PiVo_AVX2_Optimization_Changes_and_Performance.md", "PiVo_All_Improvements_and_Performance.md"):
        f = out / "Documentation" / name
        if f.is_file():
            t = f.read_text(encoding="utf-8")
            if not t.startswith("> **Superseded"):
                f.write_text(BANNER + t, encoding="utf-8"); banners += 1
    readme = out / "README.md"
    if readme.is_file():
        t = readme.read_text(encoding="utf-8")
        t = t.replace(OLD_README, NEW_README) if OLD_README in t else t + "\n\n" + NEW_README + "\n"
        readme.write_text(t + "\nSee CORRECTIONS.md for changes since the first package.\n", encoding="utf-8")

    src = out / "Source" / "PiVo-optimized-source.zip"
    stripped = []
    if a.strip_examples and src.is_file():
        tmp = src.with_suffix(".tmp")
        with zipfile.ZipFile(src) as zin, zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zout:
            for i in zin.infolist():
                if i.filename.startswith("examples/"): stripped.append(i.filename); continue
                zout.writestr(i, zin.read(i.filename))
        tmp.replace(src)

    rows = [{"Path": p.relative_to(out).as_posix(), "Size": p.stat().st_size, "SHA256": sha(p)}
            for p in sorted(out.rglob("*")) if p.is_file()]
    (out / "FINAL_MANIFEST.json").write_text(json.dumps(rows, indent=2), encoding="utf-8")
    for r in rows:
        if sha(out / r["Path"]) != r["SHA256"]: sys.exit("Manifest verification failed: " + r["Path"])
    z = out.with_suffix(".zip")
    if z.exists(): z.unlink()
    with zipfile.ZipFile(z, "w", zipfile.ZIP_DEFLATED) as zf:
        for p in sorted(out.rglob("*")):
            if p.is_file(): zf.write(p, p.relative_to(out).as_posix())
    print(f"Files in package: {len(rows) + 1}")
    print(f"Doc banners added: {banners}; source files stripped: {stripped or 'none'}")
    print(f"Zip: {z}\nSize: {z.stat().st_size}\nSHA256: {sha(z)}")

if __name__ == "__main__": main()
